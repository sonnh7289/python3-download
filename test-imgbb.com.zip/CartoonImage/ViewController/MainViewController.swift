//
//  ViewController.swift
//  CartoonImage
//
//  Created by ATULA on 03/04/2023.
//

import UIKit

class MainViewController: UIViewController {
    func convertImageToBase64String (img: UIImage) -> String {
        return img.jpegData(compressionQuality: 1)?.base64EncodedString() ?? ""
    }
    @IBOutlet weak var Img:UIImageView!
    var hi:ImgModel = ImgModel()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let userImage:UIImage = UIImage(named: "images")!
        let imageData:NSData = userImage.pngData()! as NSData
        let dataImage = imageData.base64EncodedString(options: .lineLength64Characters)
        let sonaParam = ["image":dataImage]
        APIService.shared.PostImageServer(param: imageData as Data){data, error in
            if let data = data{
                self.hi = data
                print(self.hi.display_url)
            }
        }
    }


}

