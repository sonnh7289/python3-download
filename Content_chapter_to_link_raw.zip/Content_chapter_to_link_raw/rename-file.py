import os

def rename_files_in_directory(directory, base_name, start_number):
    try:
        for i, filename in enumerate(os.listdir(directory), start=start_number):
            old_name = os.path.join(directory, filename)
            new_name = os.path.join(directory, f"{base_name}.{str(i).zfill(3)}")
            os.rename(old_name, new_name)
            print(f"File renamed successfully: {old_name} -> {new_name}")
    except FileNotFoundError:
        print(f"Directory not found: {directory}")
    except Exception as e:
        print(f"An error occurred: {e}")

# Example usage"
directory_path = "D:\\Data\\47GBManga"  # Replace with the actual path to the directory containing the files
base_name = "file.db"  # Replace with the base name you want for the files
start_number = 1  # The starting number for the sequential numbering

rename_files_in_directory(directory_path, base_name, start_number)
