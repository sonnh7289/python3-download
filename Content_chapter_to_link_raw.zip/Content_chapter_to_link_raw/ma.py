import sqlite3
import pyautogui as pag
import clipboard
import os
import re
POSITION={
    'github':[374, 1045],
    'micro_edge':[428, 1043],
    'commit_text':[450,700],
    'commit_button':[500,900],
    'sign_out':[1260,356],
    'account':[1838, 118],
    'sign_out_web':[1694, 884],
    'auth':[960, 425],
    'publish':[973, 664],
    'local_path':[905, 465],
    'private' :[715, 582],
    'create_repo':[949, 745]
}
def create_repo(name,link_source):
    # pag.hotkey('win','d')
    pag.click(POSITION["github"])
    # pag.hotkey('enter')
    pag.sleep(2)
    pag.hotkey('ctrl','n')
    pag.sleep(2)
    pag.typewrite(name)
    pag.click(POSITION["local_path"])
    pag.sleep(2)
    pag.hotkey('ctrl','a')
    
    pag.typewrite(link_source)
    pag.click(POSITION['create_repo'])
    while pag.locateOnScreen("D:\Data\Crawl\cre_repo.png"):
        pag.sleep(1)
        print("waiting create repo...")
    
    pag.hotkey('ctrl','p')
    pag.sleep(1)
    pag.click(POSITION["private"])
    pag.sleep(0.5) 
    pag.click(POSITION['publish'])
    pag.sleep(1)
    while pag.locateOnScreen("D:\Data\Crawl\loading_push.png") :
        pag.sleep(1)
        print("waiting push...")
    pag.hotkey('alt','f4')

#đăng xuất ở web
def sign_out():
    pag.click(POSITION["micro_edge"]) 
    # pag.hotkey('enter')   
    pag.sleep(2)
    pag.typewrite('https://github.com/')
    pag.sleep(2)
    pag.hotkey('enter')
    pag.sleep(2)
    pag.click(POSITION["account"])
    pag.sleep(1)
    pag.click(POSITION["sign_out_web"])
    pag.sleep(2)
    pag.click(POSITION["auth"])
    pag.sleep(6)
    pag.hotkey('alt','f4')
    pag.sleep(1)

#đăng nhập 
def sign_in(acc):
    # pag.hotkey('win','d')
    pag.click(POSITION["github"])
    # pag.hotkey('enter')
    pag.sleep(4)
    pag.hotkey('ctrl',',')
    pag.sleep(2)
    pag.click(POSITION["sign_out"])
    pag.sleep(2)
    pag.click(POSITION["sign_out"])
    pag.sleep(2)
    pag.hotkey('enter')
    while pag.locateOnScreen("D:\Data\Crawl\sign_out.png"):
        pag.sleep(1)
        print("waiting sign out...")
    while not pag.locateOnScreen("D:\Data\Crawl\sign.png"):
        pag.sleep(1)
        print("waiting sign in...")
    pag.sleep(1)
    pag.hotkey('ctrl','a')
    pag.typewrite(acc[0])
    pag.hotkey('tab')
    pag.typewrite(acc[1])
    pag.hotkey('enter')
    while pag.locateOnScreen("D:\Data\Crawl\sign.png"):
        pag.sleep(1)
        print("waiting sign in2...")
    pag.sleep(1)
    while pag.locateOnScreen("D:\Data\Crawl\sign_out.png"):
        pag.sleep(1)
        print("waiting sign in...")

def swich_acc(acc):
    sign_out()
    sign_in(acc)
    pag.sleep(2)
    pag.click(POSITION['micro_edge'])
    pag.sleep(1)
    pag.hotkey('ctrl','w')
    pag.sleep(1)
    pag.hotkey('win','d')
    pag.press('f5')

#Tải file

#Lấy đường dẫn hiện tại 

def get_name_file(text) :
    text = row[0].split('/')
    file_name = f"{text[-2].split('_')[-1]}-{text[-1]}.txt"
    return file_name

def get_link(acc,repo,list_file):
    accout = acc[2]
    list = []
    for file in list_file:    
        link = "https://github.com/" + str(accout) +"/"+ str(repo) + "/blob/main/"  + file + "?raw=true" 
        link = re.sub(r"\s","%20",link)
        list.append(link)
    return list

accout_list = [
               [r'trinhquyendiep2002@gmail.com','Quyendiep2002','Pie-D02'],
               [r'huyentrang20ngo2@gmail.com','Quyendiep2002','Pie-D03'],
               [r'trinhdiep.pie02@gmail.com','Quyendiep2002','Pie-D04'],
               [r'trinhdiep.pie03@gmail.com','Quyendiep2002','Pie-D05'],

]

db_file_path = "E:\Project App Manga ThinkDrff\son.db"
LINK = "D:\\Data\\Crawl\\"
list_id_manga = []
list_file = []
list_raw = []
count_repo = 0
acc = 0
count_txt = 0
try:
    connection = sqlite3.connect(db_file_path)
    cursor = connection.cursor()
    cursor.execute("""SELECT * FROM ListChapterTruyenChu""")
    rows = cursor.fetchmany(80000)
    for row in rows:
        
        id_chapter = row[0].split('/')
        id_manga =  row[1].split('/')[-1]

        if list_id_manga.count(id_manga) == 0 or count_txt == 1000:
            if(count_txt == 1000):
                create_repo(list_id_manga[-1],LINK)
                list_raw += get_link(accout_list[acc],list_id_manga[-1],list_file)
                count_txt = 0
            if(list_id_manga.count(id_manga) == 0) :
                if(len(list_id_manga) > 0) :
                    if(count_repo == 50) :
                        acc = acc + 1
                        swich_acc(accout_list[acc])
                        count_repo = 0
                    create_repo(list_id_manga[-1],LINK)
                    count_repo = count_repo + 1
                    list_raw += get_link(accout_list[acc],list_id_manga[-1],list_file)
                    list_file = []

                list_id_manga.append(id_manga)
                os.makedirs(id_manga)
  
        file_name = get_name_file(id_chapter)
        list_file.append(file_name)
        file_path = os.path.join(id_manga, file_name)
      

        with open(file_path, "w", encoding="utf-8") as txt_file:
            txt_file.write(row[2]) 
        count_txt = count_txt + 1
    if(count_repo == 50) :
        acc = acc + 1
        swich_acc(accout_list[acc])
    create_repo(list_id_manga[-1],LINK)
    count_repo = count_repo + 1
    list_raw += get_link(accout_list[acc],list_id_manga[-1],list_file)
    list_file = []
    connection.close()               
except Exception as e:
    print(e)
i = 0

file_path = "D:\\Data\\Crawl\\raw.txt"
# try:
#     connection = sqlite3.connect(db_file_path)
#     cursor = connection.cursor()
    
#     cursor.execute("""SELECT * FROM ListChapterTruyenChu""")
#     rows = cursor.fetchall()
#     for row in rows:
#         cursor.execute(f"UPDATE ListChapterTruyenChu SET content_chapter = '{list_raw[i]}' WHERE id_chapter = '{row[0]}'")
#         connection.commit()
#         i = i + 1
#     connection.close()
# except Exception as e :
#     print(e)
with open(file_path, "w", encoding="utf-8") as txt_file:
    for raw in list_raw :
        txt_file.write(raw)
