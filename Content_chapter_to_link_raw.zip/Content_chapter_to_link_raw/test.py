import pyautogui as py
import psutil
POSITION={
    'github':[374, 1045],
    'micro_edge':[428, 1043],
    'commit_text':[450,700],
    'commit_button':[500,900],
    'sign_out':[1260,356],
    'account':[1838, 118],
    'sign_out_web':[1694, 884],
    'auth':[960, 425],
    'publish':[973, 664],
    'local_path':[905, 465],
    'private' :[715, 582]
}
# def close_edge_browser():
#     # Duyệt qua tất cả các quy trình đang chạy trên máy tính
#     for process in psutil.process_iter(['pid', 'name']):
#         # Kiểm tra xem quy trình có tên là 'msedge.exe' hay không
#         # print(process  )
#         # print('\n')
#         if process.info['name'] == 'msedge.exe':
#             try:
#                 # Tìm thấy quy trình msedge.exe, đóng nó
#                 p = psutil.Process(process.info['pid'])
#                 p.terminate()
#                 print(process)
#             except psutil.NoSuchProcess:
#                 pass

# if __name__ == "__main__":
#     close_edge_browser()
# py.click(POSITION['github'])
# py.sleep(2)
# while py.locateOnScreen('D:\Data\Crawl\push_succ.png') :
#     print('true')
# print('false')
# print(py.position())
file_path = "D:\\Data\\Crawl\\raw.txt"
count = 0
with open(file_path, "r", encoding="utf-8") as txt_file:
    while(txt_file.readline()) :
        count += 1
print(count)