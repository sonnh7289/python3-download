import datetime
import os
import pickle
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from google_apis import create_service


def upload_video():

    CLIENT_SECRET_FILE = '/home/nghia/upload_video/youtube-upload/client_secret.json'
    API_NAME = 'youtube'
    API_VERSION = 'v3'
    SCOPES = ['https://www.googleapis.com/auth/youtube.upload']

    youtube_service = create_service(CLIENT_SECRET_FILE, API_NAME, API_VERSION, SCOPES)


    video_title = 'video demo upload to YouTube'
    video_description = 'music'
    video_tags = ['emotion']
    video_category_id = '22'
    video_privacy_status = 'private'
    video_file = '/home/nghia/upload_video/youtube-upload/music.mp4'

    upload_time = (datetime.datetime.now()).isoformat() + '.000Z'

    request_body = {
        'snippet': {
            'title': video_title,
            'description': video_description,
            'tags': video_tags,
            'categoryId': video_category_id
        },
        'status': {
            'privacyStatus': video_privacy_status,
            'publishedAt': upload_time,
            'selfDeclaredMadeForKids': False
        },
    }

    media_file = MediaFileUpload(video_file)

    try:
        print(1)
        response = youtube_service.videos().insert(
            part='snippet,status',
            body=request_body,
            media_body=media_file
        ).execute()

        request = youtube_service.videos().insert(
        part='snippet,status',
        body=request_body
        )

        #get id of video. notifi
        uploaded_video_id = response.get('id')

        print('upload video perfect. ID:', uploaded_video_id)
    except Exception as e:
        print('Error up video:', str(e))

upload_video()
