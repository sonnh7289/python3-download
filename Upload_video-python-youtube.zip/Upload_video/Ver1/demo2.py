from youtube_upload.client import YoutubeUploader


secrets_file_path = r'/home/nghia/upload_video/youtube-upload/client_secret.json'

uploader = YoutubeUploader(secrets_file_path = secrets_file_path)

uploader.authenticate()

options = {
    "title" : "huongdan upload vir2",
    "description" : "demo upload video to yotube",
    "tags" : ["test"],
    "categoryId" : "22",
    "privacyStatus" : "private",
    "kids" : False,
    "thumbnailLink" : "youtu.png"
}
uploader.upload('/home/nghia/upload_video/youtube-upload/demo_upload.mkv', options)


# response_thumbnail_upload = uploader.service.thumbnails().set(
#     videoId=uploaded_video_id,
#      media_body=MediaFileUpload('th.jpeg')
#  ).execute()



uploader.close()
