package com.example.btl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BtlApplicationTests {

	@Test
	void contextLoads() {
	}

}
