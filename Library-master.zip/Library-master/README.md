# Library
Trang thư viện online cơ bản với các tính năng của người dùng (user) và và người quản lý (admin)
1. Chức năng đăng ký
   - Chỉ dành cho người dùng
   - Có các thông tin tên người dùng, email, tài khoản, mật khẩu
2. Chức năng quản lý thư viện
   - chỉ dành cho người quản lý
   - Có các chức năng: Thêm sách, Xem chi tiết sách, Chỉnh sửa sách
