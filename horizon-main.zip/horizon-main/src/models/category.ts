export interface Category {
  ID?: string;
  id?: string;
  name: string;
  slug: string;
}
