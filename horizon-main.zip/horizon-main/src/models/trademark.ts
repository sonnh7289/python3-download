export interface Trademark {
  ID: string;
  idCategory: string;
  name: string;
}
