export interface Depot {
  ID: string;
  image: string;
  nameProduct: string;
  quantily: string;
  da_co: string;
  upcomingGoods: any | null;
}
