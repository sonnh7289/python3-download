export interface detailConfig {
  ID?: string;
  idProduct: string;
  content: string;
}
