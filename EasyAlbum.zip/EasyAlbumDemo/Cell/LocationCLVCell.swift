//
//  LocationCLVCell.swift
//  EasyAlbumDemo
//
//  Created by tuyetvoi on 4/13/23.
//  Copyright © 2023 Ray. All rights reserved.
//

import UIKit

class LocationCLVCell: UICollectionViewCell {
    @IBOutlet weak var image1: UIImageView!
    @IBOutlet weak var image2: UIImageView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
