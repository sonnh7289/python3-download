//
//  ViewController.swift
//  EasyAlbumDemo
//
//  Created by Ray on 2019/3/3.
//  Copyright © 2019 Ray. All rights reserved.
//

import UIKit
import EasyAlbum

class MainSelectImageViewController: UIViewController {
    func convertImageToBase64String (img: UIImage) -> String {
        return img.jpegData(compressionQuality: 1)?.base64EncodedString() ?? ""
    }
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var albumOneButton: UIButton!
    @IBOutlet weak var textViewMain: UITextView!

    private let CELL = "EasyAlbumDemoCell"
    private var datas: [AlbumData] = []
    var link1: ImgModel = ImgModel()
    var link2: ImgModel = ImgModel()
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    @IBAction func LoadLinkFix(){
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "FillLinkVC") as! FillLinkVC
        self.present(vc, animated: true)
    }
    
    @IBAction func NextPro(){
        if datas.count > 1{
            let imageData:NSData = self.datas[0].image.pngData()! as NSData
            APIService.shared.PostImageServer(key: "938c8d9c19d7ec0c6f5225d69a3ef3ae", param: imageData as Data){data, error in
                if let data = data{
                    self.link1 = data
                    self.textViewMain.text = "BAT DAU POST ANH SO 1\n " + self.link1.url
                    let imageData2:NSData = self.datas[1].image.pngData()! as NSData
                    APIService.shared.Post2ImageServer(key: "0648864ce249f9b501bb3ff7735eb1cd",param1: imageData2 as Data){data2, error in
                        if let data2 = data2{
                            self.link2 = data2
                            self.textViewMain.text = "BAT DAU POST ANH SO 1\n " + self.link1.url + " \n " + self.link2.url
                            let storyboard = UIStoryboard(name: "Main", bundle: nil)
                            let vc = storyboard.instantiateViewController(withIdentifier: "SelectImageBackgroundVC") as! SelectImageBackgroundVC
                            vc.Link1 = self.link1.url
                            vc.Link2 = self.link2.url
                            self.present(vc, animated: true)
                        }else{
                            self.textViewMain.text = "BAT DAU POST ANH SO 1\n " + self.link1.url + " \n LOI KHONG UPLOAD DUOC ANH SO 2" + (data2?.link ?? "")
                        }
                    }
                }else{
                    self.textViewMain.text = "BAT DAU POST ANH SO 1\n " + "LOI KHONG UPLOAD DUOC ANH SO 1"
                }
            }
            
        }
        
    }
    
    private func setup() {
        if #available(iOS 13.0, *) {
            overrideUserInterfaceStyle = .light
        }
        
        tableView.register(UINib(nibName: CELL, bundle: nil), forCellReuseIdentifier: CELL)
        tableView.estimatedRowHeight = 70.0
        tableView.rowHeight = UITableView.automaticDimension
        tableView.dataSource = self
        tableView.delegate = self
        
        albumOneButton.layer.cornerRadius = 7.5
        albumOneButton.addTarget(self, action: #selector(click(_:)), for: .touchUpInside)
        
    
    }
    
    @objc private func click(_ btn: UIButton) {
        switch btn {
        case albumOneButton:
            EasyAlbum
                .of(appName: "EasyAlbum")
                .limit(100)
                // #cc0066
                .barTintColor(UIColor(red: 0.8, green: 0.0, blue: 0.4, alpha: 1.0))
                // #00cc66
                .pickColor(UIColor(red: 0.0, green: 0.8, blue: 0.4, alpha: 1.0))
                .sizeFactor(.auto)
                .orientation(.all)
                .start(self, delegate: self)
        default: break
        }
    }
}

extension MainSelectImageViewController: UITableViewDataSource, UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return datas.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let index = indexPath.row
        let photo = datas[index]
        let cell = tableView.dequeueReusableCell(withIdentifier: CELL, for: indexPath) as! EasyAlbumDemoCell
        let desc = """
        FileName = \(photo.fileName ?? "")
        FileUTI  = \(photo.fileUTI ?? "")
        FileSize = \(photo.fileSize / 1024)KB
        """
        cell.data = (photo.image, desc)
        return cell
    }
}

extension MainSelectImageViewController: EasyAlbumDelegate {
    func easyAlbumDidSelected(_ photos: [AlbumData]) {
        if datas.count > 0 { datas.removeAll() }
        
        datas.append(contentsOf: photos)
        tableView.reloadData()
        
        photos.forEach({ print("AlbumData = \($0)") })
    }
    
    func easyAlbumDidCanceled() {
        // do something
    }
}
