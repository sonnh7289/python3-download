//
//  NextMainVC.swift
//  EasyAlbumDemo
//
//  Created by tuyetvoi on 4/13/23.
//  Copyright © 2023 Ray. All rights reserved.
//

import UIKit

class NextMainVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

//SelectImageBackgroundVC
}
