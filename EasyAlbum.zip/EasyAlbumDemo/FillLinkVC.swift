//
//  FillLinkVC.swift
//  EasyAlbumDemo
//
//  Created by tuyetvoi on 4/13/23.
//  Copyright © 2023 Ray. All rights reserved.
//

import UIKit

class FillLinkVC: UIViewController {
    @IBOutlet weak var text1Pro: UITextField!
    @IBOutlet weak var text2Pro: UITextField!
    @IBOutlet weak var text3Pro: UITextField!
    @IBOutlet weak var text4Pro: UITextField!
    @IBOutlet weak var ketquaText: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
        text1Pro.text = "https://images.pexels.com/photos/2598024/pexels-photo-2598024.jpeg?auto=compress&cs=tinysrgb&w=800"
        text2Pro.text = "https://images.pexels.com/photos/4556737/pexels-photo-4556737.jpeg?auto=compress&cs=tinysrgb&w=800"
        text3Pro.text = "https://raw.githubusercontent.com/sonnh7289/animepro/main/1x.png"
        text4Pro.text = "https://raw.githubusercontent.com/sonnh7289/animepro/main/2x.png"
        // Do any additional setup after loading the view.
    }
    @IBAction func NextButtonPro(){
        if let text1Pro = text1Pro.text , let text2Pro = text2Pro.text , let text3Pro = text3Pro.text, let text4Pro = text4Pro.text{
            let json = [
                "Link_img1": text1Pro,
                "Link_img2": text2Pro ,
                "Link_img3": text3Pro ,
                "Link_img4": text4Pro
            ]
            let jsonData = try! JSONSerialization.data(withJSONObject: json, options: [])
            APIService.shared.PostSwapAPIPro(param:  json){data3, error in
                if let data3 = data3{
                    self.ketquaText.text = data3
                    guard let url = URL(string:data3) else { return }
                    UIApplication.shared.open(url)
                }
            }
        }
        
        
    }


}
