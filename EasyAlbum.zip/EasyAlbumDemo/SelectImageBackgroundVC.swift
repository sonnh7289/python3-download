//
//  SelectImageBackgroundVC.swift
//  EasyAlbumDemo
//
//  Created by tuyetvoi on 4/13/23.
//  Copyright © 2023 Ray. All rights reserved.
//

import UIKit
import Kingfisher

extension NSObject {
    func background(delay: Double = 0.0, background: (()->Void)? = nil, completion: (() -> Void)? = nil) {
        DispatchQueue.global(qos: .background).async {
            background?()
            if let completion = completion {
                DispatchQueue.main.asyncAfter(deadline: .now() + delay, execute: {
                    completion()
                })
            }
        }
    }
    var className: String {
        return String(describing: type(of: self))
    }
    class var className: String {
        return String(describing: self)
    }
}

class SelectImageBackgroundVC: UIViewController {
    @IBOutlet weak var collectMain: UICollectionView!
    var Link1:String = ""
    var Link2:String = ""
    @IBOutlet weak var text1Pro: UITextField!
    @IBOutlet weak var text2Pro: UITextField!
    @IBOutlet weak var text3Pro: UITextField!
    @IBOutlet weak var text4Pro: UITextField!
    var listLocation : [ListImageGocModel] = [ListImageGocModel]()
    var indexSelect = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        text1Pro.text = Link1
        text2Pro.text = Link2
        collectMain.register(UINib(nibName: LocationCLVCell.className, bundle: nil), forCellWithReuseIdentifier: LocationCLVCell.className)
        collectMain.backgroundColor = UIColor.clear
        APIService.shared.getAll_Location() { (response, error) in
            if let listData = response{
                self.listLocation = listData
                DispatchQueue.main.async {
                    self.collectMain.reloadData()
                }
            }
        }
    }
    
    @IBAction func NextApp(){
        if let text1Pro = text1Pro.text, let text2Pro = text2Pro.text, let text3Pro = text3Pro.text , let text4Pro = text4Pro.text  {
            let json = [
                "Link_img1":text1Pro,
                "Link_img2":text2Pro,
                "Link_img3": text3Pro,
                "Link_img4": text4Pro
            ]
            APIService.shared.PostSwapAPIPro(param:  json){data3, error in
                if let data3 = data3{
                    guard let url = URL(string:data3) else { return }
                    UIApplication.shared.open(url)
                }
            }
        }
        
    }
    
}
extension SelectImageBackgroundVC : UICollectionViewDelegate, UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listLocation.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "LocationCLVCell", for: indexPath) as! LocationCLVCell
        let url = URL(string: listLocation[indexPath.row].nam)
        let processor = DownsamplingImageProcessor(size: cell.image1.bounds.size)
        cell.image1.kf.indicatorType = .activity
        cell.image1.kf.setImage(
            with: url,
            placeholder: UIImage(named: "placeholderImage"),
            options: [
                .processor(processor),
                .scaleFactor(UIScreen.main.scale),
                .transition(.fade(1)),
                .cacheOriginalImage
            ])
        {
            result in
            switch result {
            case .success(let value):
                print("Task done for: \(value.source.url?.absoluteString ?? "")")
            case .failure(let error):
                print("Job failed: \(error.localizedDescription)")
            }
        }
        
        let url2 = URL(string: listLocation[indexPath.row].nu)
        let processor2 = DownsamplingImageProcessor(size: cell.image1.bounds.size)
        cell.image2.kf.indicatorType = .activity
        cell.image2.kf.setImage(
            with: url2,
            placeholder: UIImage(named: "placeholderImage"),
            options: [
                .processor(processor2),
                .scaleFactor(UIScreen.main.scale),
                .transition(.fade(1)),
                .cacheOriginalImage
            ])
        {
            result in
            switch result {
            case .success(let value):
                print("Task done for: \(value.source.url?.absoluteString ?? "")")
            case .failure(let error):
                print("Job failed: \(error.localizedDescription)")
            }
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        indexSelect = indexPath.row
        text3Pro.text = listLocation[indexSelect].nu
        text4Pro.text = listLocation[indexSelect].nam
    }
}

extension SelectImageBackgroundVC : UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        if UIDevice.current.userInterfaceIdiom == .pad {
            return 10
        }
        return 24
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if UIDevice.current.userInterfaceIdiom == .pad {
            return CGSize(width: self.view.bounds.size.width / 4 - 10 , height: 200)
            
        }
        return CGSize(width: self.view.bounds.size.width / 2 - 10, height: 200)

    }
}

