//
//  ImgModel.swift
//  CartoonImage
//
//  Created by ATULA on 03/04/2023.
//
/*
 
 {
 "data": {
 "id": "0mhVKmj",
 "title": "88feaa79edf2",
 "url_viewer": "https://ibb.co/0mhVKmj",
 "url": "https://i.ibb.co/Cmhs6m5/88feaa79edf2.png",
 "display_url": "https://i.ibb.co/Dz5gYzD/88feaa79edf2.png",
 "width": 2880,
 "height": 1736,
 "size": 833363,
 "time": 1680853534,
 "expiration": 600,
 "image": {
 "filename": "88feaa79edf2.png",
 "name": "88feaa79edf2",
 "mime": "image/png",
 "extension": "png",
 "url": "https://i.ibb.co/Cmhs6m5/88feaa79edf2.png"
 },
 "thumb": {
 "filename": "88feaa79edf2.png",
 "name": "88feaa79edf2",
 "mime": "image/png",
 "extension": "png",
 "url": "https://i.ibb.co/0mhVKmj/88feaa79edf2.png"
 },
 "medium": {
 "filename": "88feaa79edf2.png",
 "name": "88feaa79edf2",
 "mime": "image/png",
 "extension": "png",
 "url": "https://i.ibb.co/Dz5gYzD/88feaa79edf2.png"
 },
 "delete_url": "https://ibb.co/0mhVKmj/2b572a575c5d4b21d94f76e60ba63467"
 },
 "success": true,
 "status": 200
 }
 
 */
import UIKit
class ImgModel: NSObject{
    var link = ""
    var id:String = ""
    var title:String = ""
    var url_viewer:String = ""
    var url:String = ""
    var display_url:String = ""
    var width:Int = 0
    var height:Int = 0
    var size:Int = 0
    var time:Int = 0
    
    func initLoad(_ json:  [String:Any]) -> ImgModel{
        if let data = json["link"] as? String{
            link = data
        }
        if let data = json["id"] as? String{
            id = data
        }
        if let data = json["title"] as? String{
            title = data
        }
        if let data = json["url_viewer"] as? String{
            url_viewer = data
        }
        if let data = json["url"] as? String{
            url = data
        }
        if let data = json["display_url"] as? String{
            display_url = data
        }
        if let data = json["width"] as? Int{
            width = data
        }
        if let data = json["height"] as? Int{
            height = data
        }
        if let data = json["size"] as? Int{
            size = data
        }
        if let data = json["time"] as? Int{
            time = data
        }
        return self
    }
    
}

