//
//  ImgModel.swift
//  CartoonImage
//
//  Created by ATULA on 03/04/2023.
//

import UIKit
//https://raw.githubusercontent.com/sonnh7289/animepro/main/sklyhon.json
class ListImageGocModel: NSObject{
    var danam = ""
    var danu  = ""
    var dotuoi  =  0
    var id = 0
    var image = ""
    var mask = ""
    var nam = ""
    var nu = ""
    var thongtin = ""
    
    func initLoad(_ json:  [String:Any]) -> ListImageGocModel{
        if let data = json["danam"] as? String{
            self.danam = data
        }
        if let danu = json["danu"] as? String{
            self.danu = danu
        }
        if let dotuoi = json["dotuoi"] as? Int{
            self.dotuoi = dotuoi
        }
        if let id = json["id"] as? Int{
            self.id = id
        }
        if let image = json["image"] as? String{
            self.image = image
        }
        if let mask = json["mask"] as? String{
            self.mask = mask
        }
        if let nam = json["nam"] as? String{
            self.nam = nam
        }
        if let nu = json["nu"] as? String{
            self.nu = nu
        }
        if let thongtin = json["thongtin"] as? String{
            self.thongtin = thongtin
        }
        
        return self
    }
    
}

