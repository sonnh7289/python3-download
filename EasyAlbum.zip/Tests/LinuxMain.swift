import XCTest

import EasyAlbumTests

var tests = [XCTestCaseEntry]()
tests += EasyAlbumTests.allTests()
XCTMain(tests)
