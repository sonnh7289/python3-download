//
//  ViewController.swift
//  FakeLocationV3
//
//  Created by Đỗ Việt on 06/04/2023.
//

import UIKit
import Kingfisher

class ViewController: UIViewController {
    
    @IBOutlet weak var mainCLV: UICollectionView!
    @IBOutlet weak var searchtf: UITextField!
    @IBOutlet weak var tagCLV: UICollectionView!
    
    var listPlace: [PlaceModel] = [PlaceModel]()
    var fillerArray = [PlaceModel]()
    var isSearch: Bool!
    var ListTag = ["All","Vietnam","France","Italy","UK","Spain","Holland","Germany","Greece","Austria"]

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        isSearch = false
        mainCLV.register(UINib(nibName: "BackgroundCell", bundle: nil), forCellWithReuseIdentifier: "BackgroundCell")
        tagCLV.register(UINib(nibName: "tagCell", bundle: nil), forCellWithReuseIdentifier: "tagCell")
        listPlace = SqliteMangaer.shared.getData()
        fillerArray = listPlace
        mainCLV.reloadData()
    }
    
    @IBAction func onTapUpLoad() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "cameraVC") as! cameraVC
        vc.modalPresentationStyle = .fullScreen
        vc.mode = "outBack"
        self.present(vc, animated: true, completion: nil)
    }
}

extension ViewController : UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        if collectionView == tagCLV {
            return ListTag.count
        }
        
        if isSearch == false {
            return listPlace.count
        }
        return fillerArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == tagCLV {
            let object = ListTag[indexPath.row]
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "tagCell", for: indexPath) as! tagCell
            cell.nameTagLb.text = "#\(object)"
            cell.layer.cornerRadius = 5
            cell.backgroundColor = UIColor(red: .random(in: 0...1), green: .random(in: 0...1), blue: .random(in: 0...1), alpha: 1.0)
            return cell
        }
        
        let object = isSearch == false ? listPlace[indexPath.row] : fillerArray[indexPath.row]
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "BackgroundCell", for: indexPath) as! BackgroundCell
        cell.layer.cornerRadius = 16
        cell.backgroundImg.kf.setImage(with: URL(string: object.linkImage))
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if collectionView == tagCLV {
            let object = ListTag[indexPath.row]
            
            if object == "All" {
                isSearch = false
                self.mainCLV.reloadData()
            }else{
                let first2 = object.prefix(2)
                fillerArray = self.listPlace.filter({(($0.nation).localizedCaseInsensitiveContains(first2))})
                if(fillerArray.count == 0){
                    isSearch = false
                }else{
                    isSearch = true
                }
                self.mainCLV.reloadData();
            }
        }
        else{
            let object = isSearch == false ? listPlace[indexPath.row] : fillerArray[indexPath.row]
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "ViewController2") as! ViewController2
            vc.modalPresentationStyle = .fullScreen
            vc.linkImage = object.linkImage
            self.present(vc, animated: true, completion: nil)
        }
        
    }
}

extension ViewController : UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if collectionView == tagCLV {
            return CGSize(width: 100, height: 25)
        }
        
        if UIScreen.main.bounds.width == 375 && UIScreen.main.bounds.height == 667 {
            return CGSize(width: mainCLV.bounds.width / 2 - 10, height: mainCLV.bounds.height / 2 - 10)
        }
        return CGSize(width: 120, height: 154)
    }
}

extension ViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
       textField.resignFirstResponder()
       return true
    }
    
    public func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool{
        //input text
        let searchText  = textField.text! + string
        //add matching text to arrya
        fillerArray = self.listPlace.filter({(($0.nation).localizedCaseInsensitiveContains(searchText))})
        
        if(fillerArray.count == 0){
            isSearch = false
        }else{
            isSearch = true
        }
        self.mainCLV.reloadData();
        
        return true
    }
}



