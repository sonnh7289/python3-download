//
//  OverlayView.swift
//  FakeLocationV3
//
//  Created by Đỗ Việt on 17/04/2023.
//

import UIKit
import MapKit
import CoreLocation

class OverlayView: UIViewController, CLLocationManagerDelegate {
    
    var hasSetPointOrigin = false
    var pointOrigin: CGPoint?
    
    @IBOutlet weak var map: MKMapView!
    var locationManager: CLLocationManager = CLLocationManager()
    
    @IBOutlet weak var slideIdicator: UIView!
    @IBOutlet weak var currentDayLb: UILabel!
    @IBOutlet weak var cityLb: UILabel!
    @IBOutlet weak var locationLb: UILabel!
    
    var timer = Timer()
    
    var callBack: ((Double,Double)->())?
    var latit: Double?
    var longit: Double?

    override func viewDidLoad() {
        super.viewDidLoad()
        let panGesture = UIPanGestureRecognizer(target: self, action: #selector(panGestureRecognizerAction))
        view.addGestureRecognizer(panGesture)

        slideIdicator.layer.backgroundColor = UIColor(red: 0.851, green: 0.851, blue: 0.851, alpha: 1).cgColor
        slideIdicator.layer.cornerRadius = 5.5
        
        getCurrentTime()
        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        
    }
    
    private func getCurrentTime() {
        timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector:#selector(self.currentTime) , userInfo: nil, repeats: true)
    }
    
    @objc func currentTime() {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm - E, d MMM yyyy"
        currentDayLb.text = formatter.string(from: Date())
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        
        if let location = locations.first {
            self.locationLb.text = "\(location.coordinate.latitude), \(location.coordinate.longitude)"
            
            let geocoder = CLGeocoder()
            geocoder.reverseGeocodeLocation(location) { (placemarks, error) in
                if (error != nil){
                    print("error in reverseGeocode")
                }
                let placemark = placemarks! as [CLPlacemark]
                if placemark.count>0{
                    let placemark = placemarks![0]
                    self.cityLb.text = "\(placemark.locality!), \(placemark.country!)"
                }
            }
            
            locationManager.stopUpdatingLocation()
            render(location)
        }
    }
    
    func render(_ location: CLLocation) {
        let coordinate = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        let span = MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
        let regino = MKCoordinateRegion(center: coordinate, span: span)
        
        map.setRegion(regino, animated: true)
    }
    
    override func viewDidLayoutSubviews() {
        if !hasSetPointOrigin {
            hasSetPointOrigin = true
            pointOrigin = self.view.frame.origin
        }
    }
    @objc func panGestureRecognizerAction(sender: UIPanGestureRecognizer) {
        let translation = sender.translation(in: view)
        
        // Not allowing the user to drag the view upward
        guard translation.y >= 0 else { return }
        
        // setting x as 0 because we don't want users to move the frame side ways!! Only want straight up or down
        view.frame.origin = CGPoint(x: 0, y: self.pointOrigin!.y + translation.y)
        
        if sender.state == .ended {
            let draggedToDismiss = (translation.y > view.frame.size.height/3.0)
            let dragVelocity = sender.velocity(in: view)
            if (dragVelocity.y >= 1300) || draggedToDismiss {
                self.dismiss(animated: true, completion: nil)
                callBack?(latit!,longit!)
            } else {
                // Set back to original position of the view controller
                UIView.animate(withDuration: 0.3) { [self] in
                    self.view.frame.origin = self.pointOrigin ?? CGPoint(x: 0, y: 400)
                    callBack?(latit!,longit!)
                }
            }
        }
    }
    
    @IBAction func openMap(){
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "mapVC") as! mapVC
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true, completion: nil)
        vc.locationBack = { [self]
            x,y in
            latit = x
            longit = y
            self.locationLb.text = "\(x), \(y)"
            let geoCoder = CLGeocoder()
            geoCoder.reverseGeocodeLocation(CLLocation(latitude: x, longitude: y)) { [weak self] (placemarks, error) in
                guard let self = self else { return }
                
                if let _ = error {
                    //TODO: Show alert informing the user
                    return
                }
                
                guard let placemark = placemarks?.first else {
                    //TODO: Show alert informing the user
                    return
                }
                
                let streetNumber = placemark.subThoroughfare ?? ""
                let streetName = placemark.thoroughfare ?? ""
                let country = placemark.country ?? ""
                let locality = placemark.locality ?? ""
                self.cityLb.text = "\(streetNumber),\(streetName),\(locality),\(country)"
                let coordinate = CLLocationCoordinate2D(latitude: x, longitude: y)
                let span = MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
                let regino = MKCoordinateRegion(center: coordinate, span: span)
                self.map.setRegion(regino, animated: true)
                let pin = MKPointAnnotation()
                pin.coordinate = coordinate
                self.map.addAnnotation(pin)
            }
        }
    }
}
