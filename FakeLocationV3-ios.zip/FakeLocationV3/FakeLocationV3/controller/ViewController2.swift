//
//  ViewController2.swift
//  FakeLocationV3
//
//  Created by Đỗ Việt on 07/04/2023.
//

import UIKit
import Kingfisher

class ViewController2: UIViewController, UIImagePickerControllerDelegate & UINavigationControllerDelegate {
    
    @IBOutlet weak var imageView: UIImageView!
    var linkImage = ""
    var image = UIImage()
    var mode = "inBack"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if mode == "outBack" {
            imageView.image = image
        }else{
            imageView.kf.setImage(with: URL(string: linkImage))
        }
    }
    
    @IBAction func onTapCamera(_ sender: UIButton) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "cameraVC") as! cameraVC
        vc.modalPresentationStyle = .fullScreen
        if mode == "inBack" {
            vc.linkImage = linkImage
        }
        else{
            vc.image1 = image
        }
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func onTapBack(_ sender: UIButton) {
        self.dismiss(animated: true)
    }
}


