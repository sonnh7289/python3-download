//
//  DoneVC.swift
//  FakeLocationV3
//
//  Created by Đỗ Việt on 09/04/2023.
//

import UIKit
import CoreLocation
import MapKit
import Photos

class DoneVC: UIViewController, CLLocationManagerDelegate {
    
    @IBOutlet weak var imageView: UIImageView!
    var image = UIImage()
    
    var latit: Double?
    var longit: Double?
    
    let locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imageView.image = image
        
        // Ask for Authorisation from the User.
        self.locationManager.requestAlwaysAuthorization()

        // For use in foreground
        self.locationManager.requestWhenInUseAuthorization()

        if CLLocationManager.locationServicesEnabled() {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.startUpdatingLocation()
            latit = locationManager.location?.coordinate.latitude
            longit = locationManager.location?.coordinate.longitude
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let locValue: CLLocationCoordinate2D = manager.location?.coordinate else { return }
    }
    
    func showMiracle() {
        let slideVC = OverlayView()
        slideVC.modalPresentationStyle = .custom
        slideVC.transitioningDelegate = self
        slideVC.latit = locationManager.location?.coordinate.latitude
        slideVC.longit = locationManager.location?.coordinate.longitude
        self.present(slideVC, animated: true, completion: nil)
        slideVC.callBack = { [self]
            x,y in
            if x != locationManager.location?.coordinate.latitude {
                latit = x
            }
            
            if y != locationManager.location?.coordinate.longitude {
                longit = y
            }
        }
    }
    
    @IBAction func onTapBack(){
        self.dismiss(animated: true)
    }
    
    @IBAction func onTapDone(){
        showAlertWith(title: "Saved!", message: "Your image will save to your photos.")
    }
    
    func showAlertWith(title: String, message: String){
        let ac = UIAlertController(title: title, message: message, preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: "Continue Editing", style: .default){
            _ in
            self.dismiss(animated: true)
        })
        ac.addAction(UIAlertAction(title: "OK", style: .default){ [self]
            _ in
            
            let image:UIImage = imageView.image! // your UIImage

            // create filename
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy.MM.dd-HH.mm.ss"
            let now = Date()
            let date_time = dateFormatter.string(from: now)
            let fileName:String = "your_image_"+date_time+".jpg" // name your file the way you want
            let temporaryFolder:URL = FileManager.default.temporaryDirectory
            let temporaryFileURL:URL = temporaryFolder.appendingPathComponent(fileName)
            
            // save the image to chosen path
            let jpeg = image.jpegData(compressionQuality: 1.0)! // set JPG quality here (1.0 is best)
            let src = CGImageSourceCreateWithData(jpeg as CFData, nil)!
            let uti = CGImageSourceGetType(src)!
            let cfPath = CFURLCreateWithFileSystemPath(nil, temporaryFileURL.path as CFString, CFURLPathStyle.cfurlposixPathStyle, false)
            let dest = CGImageDestinationCreateWithURL(cfPath!, uti, 1, nil)

            // create GPS metadata from current location
            let gCurrentLocation = CLLocation(latitude: latit!, longitude: longit!)
            let gpsMeta = gCurrentLocation.exifMetadata() // gCurrentLocation is your CLLocation (exifMetadata is an extension)
            let tiffProperties = [
                kCGImagePropertyTIFFMake as String: "Camera vendor",
                kCGImagePropertyTIFFModel as String: "Camera model"
                // --(insert other properties here if required)--
            ] as CFDictionary

            let properties = [
                kCGImagePropertyTIFFDictionary as String: tiffProperties,
                kCGImagePropertyGPSDictionary: gpsMeta as Any
                // --(insert other dictionaries here if required)--
            ] as CFDictionary

            CGImageDestinationAddImageFromSource(dest!, src, 0, properties)
            if (CGImageDestinationFinalize(dest!)) {
                
                try? PHPhotoLibrary.shared().performChangesAndWait {
                    PHAssetChangeRequest.creationRequestForAssetFromImage(atFileURL: temporaryFileURL)
                }
                
                if FileManager.default.fileExists(atPath: temporaryFileURL.path) {
                    do {
                        try FileManager.default.removeItem(atPath: temporaryFileURL.path)
                        print("Delete Success")
                    } catch {
                        print("Could not delete file, probably read-only filesystem")
                    }
                }
            } else {
                print("Error saving image with metadata")
            }
            
            self.view.window?.rootViewController?.dismiss(animated: true, completion: nil) 
        })
        present(ac, animated: true)
    }
    
    @IBAction func onTap3Dot(){
        showMiracle()
    }
    
    
}

extension DoneVC: UIViewControllerTransitioningDelegate {
    func presentationController(forPresented presented: UIViewController, presenting: UIViewController?, source: UIViewController) -> UIPresentationController? {
        PresentationController(presentedViewController: presented, presenting: presenting)
    }
}

extension CLLocation {
    func exifMetadata(heading:CLHeading? = nil) -> NSMutableDictionary {
        let GPSMetadata = NSMutableDictionary()
        let altitudeRef = Int(self.altitude < 0.0 ? 1 : 0)
        let latitudeRef = self.coordinate.latitude < 0.0 ? "S" : "N"
        let longitudeRef = self.coordinate.longitude < 0.0 ? "W" : "E"

        // GPS metadata
        GPSMetadata[(kCGImagePropertyGPSLatitude as String)] = abs(self.coordinate.latitude)
        GPSMetadata[(kCGImagePropertyGPSLongitude as String)] = abs(self.coordinate.longitude)
        GPSMetadata[(kCGImagePropertyGPSLatitudeRef as String)] = latitudeRef
        GPSMetadata[(kCGImagePropertyGPSLongitudeRef as String)] = longitudeRef
        GPSMetadata[(kCGImagePropertyGPSAltitude as String)] = Int(abs(self.altitude))
        GPSMetadata[(kCGImagePropertyGPSAltitudeRef as String)] = altitudeRef
        GPSMetadata[(kCGImagePropertyGPSTimeStamp as String)] = self.timestamp.isoTime()
        GPSMetadata[(kCGImagePropertyGPSDateStamp as String)] = self.timestamp.isoDate()
        GPSMetadata[(kCGImagePropertyGPSVersion as String)] = "2.2.0.0"

        if let heading = heading {
            GPSMetadata[(kCGImagePropertyGPSImgDirection as String)] = heading.trueHeading
            GPSMetadata[(kCGImagePropertyGPSImgDirectionRef as String)] = "T"
        }

        return GPSMetadata
    }
}

extension Date {

    func isoDate() -> String {
        let f = DateFormatter()
        f.timeZone = TimeZone(abbreviation: "UTC")
        f.dateFormat = "yyyy:MM:dd"
        return f.string(from: self)
    }

    func isoTime() -> String {
        let f = DateFormatter()
        f.timeZone = TimeZone(abbreviation: "UTC")
        f.dateFormat = "HH:mm:ss.SSSSSS"
        return f.string(from: self)
    }
}

