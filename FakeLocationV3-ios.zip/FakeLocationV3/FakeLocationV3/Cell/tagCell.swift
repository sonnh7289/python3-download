//
//  tagCell.swift
//  FakeLocationV3
//
//  Created by Đỗ Việt on 19/04/2023.
//

import UIKit

class tagCell: UICollectionViewCell {
    
    @IBOutlet weak var nameTagLb: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
