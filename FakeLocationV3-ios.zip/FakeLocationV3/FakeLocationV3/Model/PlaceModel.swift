//
//  File.swift
//  FakeLocationV3
//
//  Created by Đỗ Việt on 14/04/2023.
//

import Foundation

class PlaceModel: NSObject {
    var id:Int = 0
    var name:String = ""
    var nation:String = ""
    var city:String = ""
    var location: String = ""
    var linkImage: String = ""
    
    func initModel(id: Int, name: String, nation: String, city: String, location: String, linkImage: String) -> PlaceModel {
        self.id = id
        self.name = name
        self.nation = nation
        self.city = city
        self.location = location
        self.linkImage = linkImage
        return self
    }
}
