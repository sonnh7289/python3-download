//
//  CelebModel.swift
//  FakeLocationV3
//
//  Created by Đỗ Việt on 14/04/2023.
//

import Foundation

class CelebModel: Codable {
    var id : Int = 0
    var linkanh : String = ""
    var muc_do_soc : String = ""
    var quocgia : String = ""
    var ten : String = ""

    func initLoad(_ json:  [String: Any]) -> CelebModel{
        if let temp = json["id"] as? Int { id = temp}
        if let temp = json["linkanh"] as? String { linkanh = temp}
        if let temp = json["muc_do_soc"] as? String { muc_do_soc = temp}
        if let temp = json["quocgia"] as? String { quocgia = temp}
        if let temp = json["ten"] as? String { ten = temp}
        return self
    }
}

