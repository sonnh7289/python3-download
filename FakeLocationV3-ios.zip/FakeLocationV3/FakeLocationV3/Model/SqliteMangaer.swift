//
//  SqliteMangaer.swift
//  FakeLocationV3
//
//  Created by Đỗ Việt on 14/04/2023.
//

import Foundation
import UIKit
import SQLite

class SqliteMangaer: NSObject {
    static let shared = SqliteMangaer()
    
    var listPlace: [PlaceModel] = [PlaceModel]()
    
    var connection: Connection?
    override init() {
        let dbURL = Bundle.main.url(forResource: "data", withExtension: "db")!
        var newURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        newURL.appendPathComponent("data,db")
        do {
            if FileManager.default.fileExists(atPath: newURL.path) {
            }else {
                try FileManager.default.copyItem(atPath: dbURL.path, toPath: newURL.path)
            }
            print(newURL.path)
        } catch {
            print(error.localizedDescription)
        }
        do{
            connection = try Connection(newURL.path)
        } catch{
            connection = nil
            let nserr = error as NSError
            print("Cannot connect to Database. Error is: \(nserr), \(nserr.userInfo)")
        }
    }
    
    func getData() -> [PlaceModel] {
        let Id = Expression<Int>("Id")
        let Name = Expression<String>("Name")
        let Nation = Expression<String>("Nation")
        let City = Expression<String>("City")
        let Location = Expression<String>("Location")
        let Linkimage = Expression<String>("Link image")
        
        listPlace.removeAll()
        
        if let DatabaseRoot = connection{
            do {
                let table = Table("Fake Location Image")
                for item in try DatabaseRoot.prepare(table) {
                    var itemAdd:PlaceModel = PlaceModel()
                    itemAdd = itemAdd.initModel(id: item[Id], name: item[Name], nation: item[Nation], city: item[City], location: item[Location], linkImage: item[Linkimage])
                    listPlace.append(itemAdd)
                }
            } catch  {
                print(error)
                
            }
        }
        return listPlace
    }
}
