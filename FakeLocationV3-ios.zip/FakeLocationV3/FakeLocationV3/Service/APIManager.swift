//
//  APIManager.swift
//  FakeLocationV3
//
//  Created by Đỗ Việt on 10/04/2023.
//

import Foundation
import UIKit

enum APIError: Error{
    case custom(message: String)
}

typealias ApiCompletion = (_ data: Any?, _ error: Error?) -> ()

typealias ApiParam = [String: Any]

typealias Handler = (Swift.Result<Any?, APIError>)-> Void

enum ApiMethod: String {
    case GET = "GET"
    case POST = "POST"
}
extension String {
    func addingPercentEncodingForURLQueryValue() -> String? {
        let allowedCharacters = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~")
        return self.addingPercentEncoding(withAllowedCharacters: allowedCharacters)
    }
}

extension Dictionary {
    func stringFromHttpParameters() -> String {
        let parameterArray = self.map { (key, value) -> String in
            let percentEscapedKey = (key as! String).addingPercentEncodingForURLQueryValue()!
            if value is String {
                let percentEscapedValue = (value as! String).addingPercentEncodingForURLQueryValue()!
                return "\(percentEscapedKey)=\(percentEscapedValue)"
            }
            else {
                return "\(percentEscapedKey)=\(value)"
            }
        }
        return parameterArray.joined(separator: "&")
    }
}
class APIService:NSObject {
    static let shared: APIService = APIService()
    //   pod 'SwiftKeychainWrapper'

    func requestSON(_ url: String,
                    param: ApiParam?,
                    method: ApiMethod,
                    loading: Bool,
                    completion: @escaping ApiCompletion)
    {
        var request:URLRequest!
        var urlString = url.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)

        // set method & param
        if method == .GET {
            if let paramString = param?.stringFromHttpParameters() {
                request = URLRequest(url: URL(string:"\(urlString)?\(paramString)")!)
                let headers: Dictionary = ["Content-Type": "application/json"]
                request.allHTTPHeaderFields = headers
            }
            else {
                request = URLRequest(url: URL(string:urlString!)!)
                let headers: Dictionary = ["Content-Type": "application/json"]
                request.allHTTPHeaderFields = headers
            }
        }
        else if method == .POST {
            request = URLRequest(url: URL(string:url)!)
            
            // content-type
            let headers: Dictionary = ["Content-Type": "application/json"]
            request.allHTTPHeaderFields = headers
            
            do {
                if let p = param {
                    request.httpBody = try JSONSerialization.data(withJSONObject: p, options: .prettyPrinted)
                }
            } catch { }
        }
        
        request.timeoutInterval = 30
        request.httpMethod = method.rawValue
        
        //
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            
            DispatchQueue.main.async {
                
                // check for fundamental networking error
                guard let data = data, error == nil else {
                    completion(nil, error)
                    return
                }
                
                // check for http errors
                if let httpStatus = response as? HTTPURLResponse, httpStatus.statusCode != 200, let res = response {
                }
                
                if let resJson = self.convertToJson(data) {
                    completion(resJson, nil)
                }
                else if let resString = String(data: data, encoding: .utf8) {
                    completion(resString, error)
                }
                else {
                    completion(nil, error)
                }
            }
        }
        task.resume()
    }
    
    private func convertToJson(_ byData: Data) -> Any? {
        do {
            return try JSONSerialization.jsonObject(with: byData, options: [])
        } catch {
            //            self.debug("convert to json error: \(error)")
        }
        return nil
    }
    
    func getAll(closure: @escaping (_ response: [CelebModel]?, _ error: Error?) -> Void){
        requestSON("https://raw.githubusercontent.com/sonnh7289/notecolor/main/nguoinoitieng.json?fbclid=IwAR1jiMmWcg6Cb0Vwe4VDzy8HDjuROEXSPTSkfD9xamNjN60CN9pxVwCaOjU" , param: nil, method: .GET, loading: true) { (data, error) in
            if let d = data as? [[String : Any]]{
                var celebs = [CelebModel]()
                for i in d {
                    var celeb = CelebModel()
                    celeb.initLoad(i)
                    celebs.append(celeb)
                }
                closure(celebs, nil)
            }
        }
    }
}
