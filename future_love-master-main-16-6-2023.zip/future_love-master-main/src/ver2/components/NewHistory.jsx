import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import Header from "../components/Header";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/swiper-bundle.min.css";
import SwiperCore, { EffectCoverflow, Pagination, Navigation } from "swiper";

import useEventStore from "../../utils/store";

SwiperCore.use([EffectCoverflow, Pagination, Navigation]);

function NewHistory() {
  const { id } = useParams();
  const [data, setData] = useState([]);
  const setEvent = useEventStore((state) => state.setEvent);

  const fetchData = async () => {
    try {
      const response = await axios.get(
        `http://14.225.7.221:8989/lovehistory/${id}`
      );
      setData(response.data);
      setEvent(response.data);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    fetchData();
  }, [id]);

  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-r from-custom-pink to-custom-red p-10 slider-container">
      <Header />
      <Swiper
        effect="coverflow"
        grabCursor={true}
        centeredSlides={true}
        loop={true}
        slidesPerView="auto"
        coverflowEffect={{
          rotate: 0,
          stretch: 0,
          depth: 100,
          modifier: 2.5,
        }}
        className="swiper_container"
      >
        {data.map((item, index) => (
          <SwiperSlide key={index}>
            <div
              className={`section-container ${index === 0 ? "show" : ""}`}
            >
              <div className="section">
                {index > 0 && <div className="I">{index}</div>}
                <img className="imgs" src={item.link_da_swap} alt="" />
                <div className="text">{item.ten_su_kien}</div>
                <div className="text">{item.noi_dung_su_kien}</div>
                <div className="real-time">{item.real_time}</div>
              </div>
            </div>
          </SwiperSlide>
        ))}
      </Swiper>
    </div>
  );
}

export default NewHistory;
