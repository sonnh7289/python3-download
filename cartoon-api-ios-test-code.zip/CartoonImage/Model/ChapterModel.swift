//
//  ChapterModel.swift
//  CartoonImage
//
//  Created by ATULA on 03/04/2023.
//

import UIKit
class ChapterModel: NSObject{
    var image:[String] = []
    func initLoad(_ json:  [String: Any]) -> ChapterModel{
        if let data = json["image"] as? [String]{
            for item in data{
                image.append(item)
            }
        }
    return self
    }
}
 
