//
//  ViewController.swift
//  CartoonImage
//
//  Created by ATULA on 03/04/2023.
//

import UIKit

class MainViewController: UIViewController {

    @IBOutlet weak var Img:UIImageView!
    var hi:ImgModel = ImgModel()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        APIService.shared.GetData("https://znews-photo.zingcdn.me/w1920/Uploaded/qhj_yvobvhfwbv/2018_07_18/Nguyen_Huy_Binh1.jpg"){data, error in
            if let data = data{
                self.hi = data
                print(self.hi)
                let dataDecoded : Data = Data(base64Encoded: self.hi.link, options: .ignoreUnknownCharacters)!
                let decodedimage = UIImage(data: dataDecoded)
                self.Img.image = decodedimage
            }
        }
    }


}

