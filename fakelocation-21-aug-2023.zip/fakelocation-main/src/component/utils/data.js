import frame from "../images/frame.png";
import mega from "../images/mega.png";
import add from "../images/galleryadd.png";
import user from "../images/user.png";
import pagoda from "../images/pagoda.png";
import anh1 from "../images/anh1.png";
import anh2 from "../images/anh2.png";
import anh3 from "../images/anh3.png";
import right from "../images/chrevright.png";
import more from "../images/more.png";
import you2 from "../images/you2.png";
import you3 from "../images/you3.png";
import review1 from "../images/review1.png";
import edit from "../images/edit.png";
import newuser from "../images/newuser.png";
import removebg from "../images/removebg.png";
import addbg from "../images/addbg.png";
import location from "../images/location.png";
import deletebg from "../images/deletebg.png";
import savebg from "../images/savebg.png";
export {
  frame,
  you2,
  you3,
  mega,
  user,
  add,
  pagoda,
  anh1,
  anh2,
  anh3,
  right,
  more,
  review1,
  newuser,
  edit,
  savebg,
  addbg,
  removebg,
  deletebg,
  location,
};
