//
//  ViewControllerResultQuiz.swift
//  englishtochinesedictionary
//
//  Created by Phạm Đức Tùng on 30/01/2023.
//

import UIKit

class ViewControllerResultQuiz: UIViewController {
    var total:Int = 0
    var totalTrue = 0
    var totalFalse = 0
    @IBOutlet weak var lableTotal:UILabel!
    @IBOutlet weak var lableTotalTrue:UILabel!
    @IBOutlet weak var lableTotalFalse:UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        lableTotal.text = "\(total)"
        lableTotalTrue.text = "\(totalTrue)"
        lableTotalFalse.text = "\(totalFalse)"
//        print(totalTrue)
//        print(totalFalse)
    }
    
    @IBAction func loadHome() {
        let _: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vcUIViewController = self.storyboard?.instantiateViewController(withIdentifier: "ViewController1") as! ViewController1
        vcUIViewController.modalPresentationStyle = .fullScreen
        self.present(vcUIViewController, animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
