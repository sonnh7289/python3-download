//
//  ViewControllerFavorite.swift
//  englishtochinesedictionary
//
//  Created by Phạm Đức Tùng on 29/01/2023.
//

import UIKit

class ViewControllerFavorite: UIViewController {
    var listDataPro: [WordModel] = [WordModel]()
    var listFavourite: [WordModel] = [WordModel]()
    @IBOutlet weak var textField:UITextField!
    var checkSeach = false
    @IBOutlet weak var FavoriteCollectionView:UICollectionView!
    @IBAction func loadControllerFavorite(){
        let _: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vcUIViewController = self.storyboard?.instantiateViewController(withIdentifier: "ViewControllerFavorite") as! ViewControllerFavorite
        vcUIViewController.modalPresentationStyle = .fullScreen
        self.present(vcUIViewController, animated: true, completion: nil)
        
    }
    @IBAction func loadControllerQuiz(){
        let _: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vcUIViewController = self.storyboard?.instantiateViewController(withIdentifier: "ViewControllerQuiz") as! ViewControllerQuiz
        vcUIViewController.modalPresentationStyle = .fullScreen
        self.present(vcUIViewController, animated: true, completion: nil)
        
        
    }
    @IBAction func loadViewController1(){
        let _: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vcUIViewController = self.storyboard?.instantiateViewController(withIdentifier: "ViewController1") as! ViewController1
        vcUIViewController.modalPresentationStyle = .fullScreen
        self.present(vcUIViewController, animated: true, completion: nil)
       
    }
    
    // Do any additional setup after loading the view.
    
            var dataPro:[String] = [String]()
    override func viewDidLoad() {
        super.viewDidLoad()
        FavoriteCollectionView.register(UINib(nibName: "CellConCLVCellFavorite", bundle: nil), forCellWithReuseIdentifier: "CellConCLVCellFavorite")
        //            dataPro.append("TUNGPROMAX")
        //            dataPro.append("Devsenior")
        //            dataPro.append("PTIT")
        textField.addTarget(self, action: #selector(textFieldDidChanged), for: .editingChanged)
        listDataPro = ServiceChiniseSql.shared.getDataFavourite()
        print(listDataPro.count)
        FavoriteCollectionView.reloadData()
        
    }
    func getData() {
        listDataPro = ServiceChiniseSql.shared.getDataFavourite()
    }
    
//    override func viewWillAppear(_ animated: Bool) {
//        listDataPro = ServiceChiniseSql.shared.getDataFavourite()
//        FavoriteCollectionView.reloadData()
//    }
    @objc func textFieldDidChanged() {
        if textField.text == "" {
            listDataPro =  ServiceChiniseSql.shared.getDataFavourite()
        }
        else {
            listDataPro.removeAll()
            checkSeach = true
            for item in  ServiceChiniseSql.shared.getDataFavourite() {
                if item.Word.lowercased().contains(textField?.text?.lowercased() ?? "") == true {
                    listDataPro.append(item)
                }
            }
        }
        FavoriteCollectionView.reloadData()



    }
    override  func viewWillAppear(_ animated: Bool) {

        checkSeach = false
    }
    
}


extension ViewControllerFavorite: UICollectionViewDelegate, UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listDataPro.count
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "ViewControllerMeanOfWord") as! ViewControllerMeanOfWord
        vc.categoryName = listDataPro[indexPath.item].Word
        vc.categoryName2 = listDataPro[indexPath.item].Meaning
                        vc.Id = Int64(listDataPro[indexPath.item].Id)
                        vc.favorite = listDataPro[indexPath.item].is_favourite
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellConCLVCellFavorite", for: indexPath) as! CellConCLVCellFavorite
        
        cell.LabelName.text = listDataPro[indexPath.item].Word
        cell.LabelName2.text = listDataPro[indexPath.item].Meaning
//        cell.Id = Int64(listDataPro[indexPath.item].Id)
        
        
        cell.btnDelete.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(delecell(_:))))
        
        
        
        return cell
    }
    func collectionView(_ collectionView: UICollectionView,
                        viewForSupplementaryElementOfKind kind: String,
                        at indexPath: IndexPath) -> UICollectionReusableView {
        
        return UICollectionReusableView()
    }
    @objc func delecell(_ sender: UITapGestureRecognizer) {
        let location = sender.location(in: self.FavoriteCollectionView)
        let indexPath = self.FavoriteCollectionView.indexPathForItem(at: location)
        let id = Int64(listDataPro[indexPath!.item].Id)
        listDataPro.remove(at: indexPath!.item)
        FavoriteCollectionView.deleteItems(at: [IndexPath(item: indexPath!.item, section: 0)])
        ServiceChiniseSql.shared.unmarkedFavourite(id: id)
        getData()
        FavoriteCollectionView.reloadData()
    }
}

extension ViewControllerFavorite: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return .zero
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 20
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if UIDevice.current.userInterfaceIdiom == .pad{
            return CGSize(width: UIScreen.main.bounds.width, height: 70)
        }
        return CGSize(width: UIScreen.main.bounds.width , height: 70)
    }
}


