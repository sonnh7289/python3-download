//
//  ViewControllerShare.swift
//  englishtochinesedictionary
//
//  Created by Phạm Đức Tùng on 08/02/2023.
//

import UIKit
import WebKit
class ViewControllerShare: UIViewController , WKUIDelegate {

    var webView: WKWebView!
   
    override func viewDidLoad() {
        super.viewDidLoad()
             let myURL = URL(string:"https://www.facebook.com")
             let myRequest = URLRequest(url: myURL!)
             webView.load(myRequest)
        
    }
         override func loadView() {
          let webConfiguration = WKWebViewConfiguration()
          webView = WKWebView(frame: .zero, configuration: webConfiguration)
          webView.uiDelegate = self
          view = webView
       }

}
