//
//  ViewControllerMeanOfWord.swift
//  englishtochinesedictionary
//
//  Created by Phạm Đức Tùng on 31/01/2023.
//

import UIKit
import WebKit
import AVFoundation
class ViewControllerMeanOfWord: UIViewController {
    
    @IBOutlet weak var tienganh: UILabel!
    @IBOutlet weak var tiengTrung: UILabel!
    @IBOutlet weak var imageTraiTim:UIImageView!
 
    var Id:Int64 = 0
    var favorite:Int = 10
    @IBAction func loadControllerFavorite(){
        let _: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vcUIViewController = self.storyboard?.instantiateViewController(withIdentifier: "ViewControllerFavorite") as! ViewControllerFavorite
        vcUIViewController.modalPresentationStyle = .fullScreen
        self.present(vcUIViewController, animated: true, completion: nil)
        
        
    }
    @IBAction func loadControllerQuiz(){
        let _: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vcUIViewController = self.storyboard?.instantiateViewController(withIdentifier: "ViewControllerQuiz") as! ViewControllerQuiz
        vcUIViewController.modalPresentationStyle = .fullScreen
        self.present(vcUIViewController, animated: true, completion: nil)
        
        
    }
    @IBAction func loadViewController1(){
        let _: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vcUIViewController = self.storyboard?.instantiateViewController(withIdentifier: "ViewController1") as! ViewController1
        vcUIViewController.modalPresentationStyle = .fullScreen
        self.present(vcUIViewController, animated: true, completion: nil)
        
    }
    @IBAction func back(){
        let _: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vcUIViewController = self.storyboard?.instantiateViewController(withIdentifier: "ViewController1") as! ViewController1
        vcUIViewController.modalPresentationStyle = .fullScreen
        self.present(vcUIViewController, animated: true, completion: nil)
       
    }
    var categoryName = ""
    var categoryName2 = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        
        tienganh.text = categoryName
        tiengTrung.text = categoryName2
        if  ServiceChiniseSql.shared.didMarkedFavourite(id: Id) == true {
            imageTraiTim.image = UIImage(named: "TraiTim2")
            
        }
        else {
            imageTraiTim.image = UIImage(named: "TraiTim1")
            

        }
        // Do any additional setup after loading the view.
       
    }
    @IBAction func ThemFavorite() {
        
        let _: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vcUIViewController = self.storyboard?.instantiateViewController(withIdentifier: "ViewControllerFavorite") as! ViewControllerFavorite
        vcUIViewController.modalPresentationStyle = .fullScreen
        self.present(vcUIViewController, animated: true, completion: nil)

//        let vc = storyboard?.instantiateViewController(withIdentifier: "ViewControllerFavorite") as! ViewControllerFavorite
//        vc.dataPro.append(categoryName)
//        vcUIViewController.dataPro.append(categoryName)
    
//        ServiceChiniseSql.shared.markedFavourite(id: Id)
        if  ServiceChiniseSql.shared.didMarkedFavourite(id: Id) == true {
            
            ServiceChiniseSql.shared.unmarkedFavourite(id: Id)
        }
        else {
           
            ServiceChiniseSql.shared.markedFavourite(id: Id)
//            ServiceChiniseSql.shared.resetFavourite()

        }
        vcUIViewController.listDataPro = ServiceChiniseSql.shared.getDataFavourite()
//        print("da them")
        
        
    }
    @IBAction func share() {
        let _: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vcUIViewController = self.storyboard?.instantiateViewController(withIdentifier: "ViewControllerShare") as! ViewControllerShare
        vcUIViewController.modalPresentationStyle = .fullScreen
        self.present(vcUIViewController, animated: true, completion: nil)
    }
    @IBAction func Speak() {
        let utterance = AVSpeechUtterance(string: categoryName2)
        utterance.voice = AVSpeechSynthesisVoice(language: "zh-CN")
        utterance.volume = 1
        utterance.rate = 0.1
        let synthesizer = AVSpeechSynthesizer()
        synthesizer.speak(utterance)
    }
    
        
        
    
   
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
