//
//  ViewControllerQuiz.swift
//  englishtochinesedictionary
//
//  Created by Phạm Đức Tùng on 29/01/2023.
//

import UIKit
import Foundation
class ViewControllerQuiz: UIViewController {
    var listWord: [QuizModel] = [QuizModel]()
    @IBOutlet weak var quizCollectionView:UICollectionView!
    @IBOutlet weak var lableQuestion:UILabel!
    @IBOutlet weak var lableTrue:UILabel!
    @IBOutlet weak var lableFalse:UILabel!
    var dataQuestion: [String] = []
    var i: Int = 0
    var answerTrue:Int = 0
    var answerFalse:Int = 0
    @IBAction func loadControllerFavorite(){
        let _: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vcUIViewController = self.storyboard?.instantiateViewController(withIdentifier: "ViewControllerFavorite") as! ViewControllerFavorite
        vcUIViewController.modalPresentationStyle = .fullScreen
        self.present(vcUIViewController, animated: true, completion: nil)
        
        
    }
    @IBAction func loadControllerQuiz(){
        let _: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vcUIViewController = self.storyboard?.instantiateViewController(withIdentifier: "ViewControllerQuiz") as! ViewControllerQuiz
        vcUIViewController.modalPresentationStyle = .fullScreen
        self.present(vcUIViewController, animated: true, completion: nil)
        
    }
    @IBAction func loadViewController1(){
        let _: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vcUIViewController = self.storyboard?.instantiateViewController(withIdentifier: "ViewController1") as! ViewController1
        vcUIViewController.modalPresentationStyle = .fullScreen
        self.present(vcUIViewController, animated: true, completion: nil)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        quizCollectionView.register(UINib(nibName: "CellAnser", bundle: nil), forCellWithReuseIdentifier: "CellAnser")
        listWord =  ServiceQuizSql.shared.getDataWord()
//        print(listWord.count)
        quizCollectionView.reloadData()
        // Do any additional setup after loading the view.
    }
    
}
extension ViewControllerQuiz: UICollectionViewDelegate, UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 4
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell = quizCollectionView.cellForItem(at: indexPath) as! CellAnser
      
        if cell.lableAnser.text == listWord[i].Answer_true {
            cell.imageChose.image = UIImage(named: "ChoseTrue")
            cell.imageChose2.image = UIImage(named: "imageChose")
//            print("chon dung")
                        i += 1
            answerTrue += 1
            lableTrue.text = "\(answerTrue)"
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                self.quizCollectionView.reloadData()
            
            }
            
           
        }
        else  {
            i += 1
            cell.imageChose2.image = UIImage(named: "imageChose")
            cell.imageChose.image = UIImage(named: "ChoseFalse")
            answerFalse += 1
            lableFalse.text = "\(answerFalse)"
           
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                
                self.quizCollectionView.reloadData()
            }
           
        }

        if i == listWord.count - 1  {
            let vc = storyboard?.instantiateViewController(withIdentifier: "ViewControllerResultQuiz") as! ViewControllerResultQuiz
            vc.total = listWord.count - 1
            vc.totalTrue = answerTrue
            vc.totalFalse = answerFalse
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true)
        }
       
//        quizCollectionView.reloadData()
        
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellAnser", for: indexPath) as! CellAnser
                cell.imageChose.image = UIImage(named: "BackGroudAnser1")
                cell.imageChose2.image = UIImage(named: "BackGroudAnser2")
        
        if indexPath.item == 0 {
            cell.lableAnser.text = listWord[i].Answer_1
            lableQuestion.text = listWord[i].Question
            cell.imageABCD.image = UIImage(named: "A")
           
        } else if indexPath.item == 1 {
            cell.lableAnser.text = listWord[i].Answer_2
            cell.imageABCD.image = UIImage(named: "B")
           
        } else if indexPath.item == 2 {
            cell.lableAnser.text = listWord[i].Answer_3
            cell.imageABCD.image = UIImage(named: "C")
          
        } else if indexPath.item == 3 {
            cell.lableAnser.text = listWord[i].Answer_4
            cell.imageABCD.image = UIImage(named: "D")
            
        }
        
        
        return cell
       
    }
    func collectionView(_ collectionView: UICollectionView,
                        viewForSupplementaryElementOfKind kind: String,
                        at indexPath: IndexPath) -> UICollectionReusableView {
        
        return UICollectionReusableView()
    }
}


extension ViewControllerQuiz: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return .zero
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 20
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if UIDevice.current.userInterfaceIdiom == .pad{
            return CGSize(width: UIScreen.main.bounds.width, height: 50)
        }
        return CGSize(width: UIScreen.main.bounds.width/2 - 10, height: 50)
    }
}


