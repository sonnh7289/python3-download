//
//  ViewController.swift
//  englishtochinesedictionary
//
//  Created by Phạm Đức Tùng on 12/01/2023.
//

import UIKit

class ViewController1: UIViewController {
    @IBOutlet weak var MainCollectionView:UICollectionView!
    @IBOutlet weak var textField:UITextField!
    
    var checkSeach = false
    var listWordSeach: [WordModel] = [WordModel]()
    var listWord: [WordModel] = [WordModel]()
    
    @IBAction func loadControllerFavorite(){
        let _: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vcUIViewController = self.storyboard?.instantiateViewController(withIdentifier: "ViewControllerFavorite") as! ViewControllerFavorite
        vcUIViewController.modalPresentationStyle = .fullScreen
        self.present(vcUIViewController, animated: true, completion: nil)
       
    }
    
    @IBAction func loadControllerQuiz(){
        let _: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vcUIViewController = self.storyboard?.instantiateViewController(withIdentifier: "ViewControllerQuiz") as! ViewControllerQuiz
        vcUIViewController.modalPresentationStyle = .fullScreen
        self.present(vcUIViewController, animated: true, completion: nil)
       
        
    }
    @IBAction func loadViewController1(){
        let _: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vcUIViewController = self.storyboard?.instantiateViewController(withIdentifier: "ViewController1") as! ViewController1
        vcUIViewController.modalPresentationStyle = .fullScreen
        self.present(vcUIViewController, animated: true, completion: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        textField.addTarget(self, action: #selector(textFieldDidChanged), for: .editingChanged)
      
        MainCollectionView.register(UINib(nibName: "CellConCLVCell", bundle: nil), forCellWithReuseIdentifier: "CellConCLVCell")
        listWord =  ServiceChiniseSql.shared.getDataWord()
        MainCollectionView.reloadData()
       
    }
    @objc func textFieldDidChanged() {
        if textField.text == "" {
            listWord =  ServiceChiniseSql.shared.getDataWord()
        }
        else {
            listWord.removeAll()
            checkSeach = true
            for item in  ServiceChiniseSql.shared.listWord {
                if item.Word.lowercased().contains(textField?.text?.lowercased() ?? "") == true {
                    listWord.append(item)
                }
            }
        }
        MainCollectionView.reloadData()
       
       
         
    }
    override  func viewWillAppear(_ animated: Bool) {
        
      checkSeach = false
    }
}


extension ViewController1: UICollectionViewDelegate, UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.listWord.count
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "ViewControllerMeanOfWord") as! ViewControllerMeanOfWord
        vc.categoryName = listWord[indexPath.item].Word
        vc.categoryName2 = listWord[indexPath.item].Meaning
        vc.Id = Int64(listWord[indexPath.item].Id)
        vc.favorite = listWord[indexPath.item].is_favourite
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellConCLVCell", for: indexPath) as! CellConCLVCell
        cell.LabelName.text = self.listWord[indexPath.item].Word
        cell.LabelName2.text = self.listWord[indexPath.item].Meaning
        return cell
        
    }
    func collectionView(_ collectionView: UICollectionView,
                        viewForSupplementaryElementOfKind kind: String,
                        at indexPath: IndexPath) -> UICollectionReusableView {
        
        return UICollectionReusableView()
    }
    
}

extension ViewController1: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return .zero
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 20
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if UIDevice.current.userInterfaceIdiom == .pad{
            return CGSize(width: UIScreen.main.bounds.width, height: 70)
        }
        return CGSize(width: UIScreen.main.bounds.width , height: 70)
    }
}
