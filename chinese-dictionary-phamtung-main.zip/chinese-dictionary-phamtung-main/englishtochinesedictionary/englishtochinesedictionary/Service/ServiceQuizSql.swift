//
//  ServiceQuizSql.swift
//  englishtochinesedictionary
//
//  Created by Phạm Đức Tùng on 07/02/2023.
//

import UIKit
import SQLite
class ServiceQuizSql: NSObject {
    static let shared = ServiceQuizSql()
    var listWord: [QuizModel] = [QuizModel]()
    let users = Table("Question")
    var connection: Connection?
    let _id = Expression<Int>("_id")
    let Question = Expression<String>("Question")
    let Answer_1 = Expression<String>("Answer_1")
    let Answer_2 = Expression<String>("Answer_2")
    let Answer_3 = Expression<String>("Answer_3")
    let Answer_4 = Expression<String>("Answer_4")
    let Answer_true = Expression<String>("Answer_true")
    
    override init() {
        let dbURL = Bundle.main.url(forResource: "Question", withExtension: "db")!
        var newURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        newURL.appendPathComponent("Question,db")
        do {
            if FileManager.default.fileExists(atPath: newURL.path) {
            }else {
                try FileManager.default.copyItem(atPath: dbURL.path, toPath: newURL.path)
            }
            print(newURL.path)
        } catch {
            print(error.localizedDescription)
        }
        do{
            connection = try Connection(newURL.path)
        } catch{
            connection = nil
            let nserr = error as NSError
            print("Cannot connect to Database. Error is: \(nserr), \(nserr.userInfo)")
        }
    }
    func getDataWord() -> [QuizModel] {
        listWord.removeAll()
        if let DatabaseRoot = connection{
            do {
                let users = Table("Question")
                for users2 in try DatabaseRoot.prepare(users) {
                    var itemAdd:QuizModel = QuizModel()
                    itemAdd = itemAdd.initModel(_id: Int(users2[_id]), Question: users2[Question], Answer_1: users2[Answer_1], Answer_2: users2[Answer_2], Answer_3: users2[Answer_3], Answer_4: users2[Answer_4], Answer_true: users2[Answer_true])
                    listWord.append(itemAdd)
                }
            } catch  {
                print(error)
                
            }
        }
        return listWord
    }
    func getDataQuiz(id: Int)->[QuizModel] {
        var listAnswer: [QuizModel] = [QuizModel]()
        for item in self.listWord{
            if item._id == id {
                listAnswer.append(item)
            }
        }
        return listAnswer
    }
}
