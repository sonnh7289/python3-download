//
//  ServiceChiniseSql.swift
//  englishtochinesedictionary
//
//  Created by Phạm Đức Tùng on 31/01/2023.
//

import UIKit
import SQLite
class ServiceChiniseSql: NSObject {
    static let shared = ServiceChiniseSql()
    var listWord: [WordModel] = [WordModel]()
    var listFavourite: [WordModel] = [WordModel]()
    let users = Table("Dictionary")
    var connection: Connection?
    let Id = Expression<Int64>("Id")
    let Word = Expression<String>("Word")
    let Meaning = Expression<String>("Meaning")
    let is_favourite = Expression<Int64>("is_favourite")
    let recentwords = Expression<Int64>("recentwords")
    let recentchinese = Expression<Int64>("recentchinese")
    
    override init() {
        let dbURL = Bundle.main.url(forResource: "chineseddic", withExtension: "db")!
        var newURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        newURL.appendPathComponent("chineseddic,db")
        do {
            if FileManager.default.fileExists(atPath: newURL.path) {
            }else {
                try FileManager.default.copyItem(atPath: dbURL.path, toPath: newURL.path)
            }
            print(newURL.path)
        } catch {
            print(error.localizedDescription)
        }
        do{
            connection = try Connection(newURL.path)
        } catch{
            connection = nil
            let nserr = error as NSError
            print("Cannot connect to Database. Error is: \(nserr), \(nserr.userInfo)")
        }
    }
    func getDataWord() -> [WordModel] {
        

        listWord.removeAll()
        
        if let DatabaseRoot = connection{
            do {
                let users = Table("Dictionary")
                for users2 in try DatabaseRoot.prepare(users) {
                    var itemAdd:WordModel = WordModel()
                    itemAdd = itemAdd.initModel2(Id: Int(Int64(users2[Id])), Word: users2[Word], Meaning: users2[Meaning], is_favourite: Int(users2[is_favourite]), recentwords: Int(users2[recentwords]), recentchinese: Int(users2[recentchinese]))
                    listWord.append(itemAdd)
                }
            } catch  {
                print(error)
                
            }
        }
        return listWord
    }
    func getDataFavourite()->[WordModel] {
        var listFavourite: [WordModel] = [WordModel]()
        for item in self.listWord{
            if item.is_favourite == 1 {
                listFavourite.append(item)
            }
        }
        return listFavourite
    }
    func markedFavourite(id: Int64){
        for item in self.listWord{
            if item.Id == id {
                item.is_favourite = 1
            }
        }
        let userFilter0 = users.filter(self.Id == id)
        do{
            let updateEnglish0 = userFilter0.update(self.is_favourite <- 1)
            try connection!.run(updateEnglish0)
        } catch{
            print("Update failed: \(error)")
        }
        
    }
    func unmarkedFavourite(id: Int64){
        for item in self.listWord{
            if item.Id == id {
                item.is_favourite = 0
            }
        }
        let userFilter = users.filter(self.Id == id)
        do{
            let updateEnglish = userFilter.update(self.is_favourite <- 0)
            try connection!.run(updateEnglish)
            
        } catch{
            print("Update failed: \(error)")
        }
        
    }
    
    func didMarkedFavourite(id: Int64)->Bool{
        for item in self.listWord{
            if item.Id == id {
                if item.is_favourite == 0 {
                    return false
                }else{
                    return true
                }
            }
        }
        return false
    }
    
    func resetFavourite() {
        for item in listWord {
            item.is_favourite = 0
        }
        let userFilter = users
        do{
            let updateEnglish = userFilter.update(self.is_favourite <- 0)
            try connection!.run(updateEnglish)
            
        } catch{
            print("Update failed: \(error)")
        }
    }
    
}
