//
//  CellConCLVCell.swift
//  englishtochinesedictionary
//
//  Created by Phạm Đức Tùng on 28/01/2023.
//

import UIKit

class CellConCLVCell: UICollectionViewCell {
    @IBOutlet weak var LabelName:UILabel!
    @IBOutlet weak var LabelName2:UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
