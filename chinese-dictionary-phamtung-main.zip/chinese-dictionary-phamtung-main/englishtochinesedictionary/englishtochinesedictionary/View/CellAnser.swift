//
//  CellAnser.swift
//  englishtochinesedictionary
//
//  Created by Phạm Đức Tùng on 06/02/2023.
//

import UIKit

class CellAnser: UICollectionViewCell {
    @IBOutlet weak var imageABCD:UIImageView!
    @IBOutlet weak var lableAnser:UILabel!
    @IBOutlet weak var imageChose:UIImageView!
    @IBOutlet weak var imageChose2:UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
