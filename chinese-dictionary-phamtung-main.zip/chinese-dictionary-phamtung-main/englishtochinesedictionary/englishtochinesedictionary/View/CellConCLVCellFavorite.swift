//
//  CellConCLVCellFavorite.swift
//  englishtochinesedictionary
//
//  Created by Phạm Đức Tùng on 30/01/2023.
//

import UIKit

class CellConCLVCellFavorite: UICollectionViewCell {
    var Id:Int64 = 0
    var check = false
    @IBOutlet weak var LabelName:UILabel!
    @IBOutlet weak var LabelName2:UILabel!
    @IBOutlet weak var btnDelete:UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
//    @IBAction func DeleteCell() {
////        ServiceChiniseSql.shared.unmarkedFavourite(id: Id)
//        print(Id)
//
//        check = true
//
//
//    }
//

}
