//
//  WordModel.swift
//  englishtochinesedictionary
//
//  Created by Phạm Đức Tùng on 31/01/2023.
//

import UIKit

class WordModel: NSObject {
    var Id:Int = 0
    var Word:String = ""
    var Meaning:String = ""
    var is_favourite:Int = 0
    var recentwords:Int = 0
    var recentchinese:Int = 0
    
    
    func initModel2(Id:Int, Word:String, Meaning:String, is_favourite:Int, recentwords:Int, recentchinese:Int) -> WordModel{
        self.Id = Id
        self.Word = Word
        self.Meaning = Meaning
        self.is_favourite = is_favourite
        self.recentwords = recentwords
        self.recentchinese = recentchinese
//        self.note = note
        return self
    }
}
