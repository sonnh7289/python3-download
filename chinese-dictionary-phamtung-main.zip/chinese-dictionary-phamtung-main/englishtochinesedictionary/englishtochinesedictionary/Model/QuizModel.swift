//
//  QuizModel.swift
//  englishtochinesedictionary
//
//  Created by Phạm Đức Tùng on 07/02/2023.
//

import UIKit

class QuizModel: NSObject {
    var _id:Int = 0
    var Question:String = ""
    var Answer_1:String = ""
    var Answer_2:String = ""
    var Answer_3:String = ""
    var Answer_4:String = ""
    var Answer_true:String = ""
    func initModel(_id:Int,Question:String, Answer_1:String, Answer_2:String, Answer_3:String, Answer_4:String, Answer_true:String) -> QuizModel{
        self._id = _id
        self.Question = Question
        self.Answer_1 = Answer_1
        self.Answer_2 = Answer_2
        self.Answer_3 = Answer_3
        self.Answer_4 = Answer_4
        self.Answer_true = Answer_true
        return self
    }
}
