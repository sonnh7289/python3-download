from source import app

import source.main.controller

if __name__ == '__main__':
    app.run()