//
//  SearchViewController.swift
//  FutureLove
//
//  Created by TTH on 08/08/2023.
//

import UIKit

class SearchViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }


    

}
