
import React from "react";
import { getFullFaceDescription } from "../../api/face";

export default async function IsValidFace(image) {
    let res = false;
    const handleImage = async () => {

        await getFullFaceDescription(image).then(fullDesc => {
          if (fullDesc.length !== 0) {
            res = true;
          }
        });

    };

    await handleImage();

    return res;
}