import pyautogui as pag
# x=1793, y=122
# x=1703, y=606
while True:
    print(pag.position())
    # while not pag.locateOnScreen(f'D:\\TOOL-PY\\Auto-Comments\\Auto-comment-Pyautogui\\image\\account1.png'):
    #     pag.sleep(1)
    #     print('waiting for launch browser 2')
    print('ko thay')
    pag.sleep(1)
