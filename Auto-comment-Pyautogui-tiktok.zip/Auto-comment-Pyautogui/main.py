import pyautogui as pag

POSITION = {
    "user": [851, 623],
    'login': [1759, 113],
    "google_login": [937, 585],
    'micro_edge': [428, 1043],
    'next_login': [1180, 713],
    'comments': [1422, 971],
    'video': [951, 664],
    'acc': [1859, 121],
    'logout': [1734, 608],
    'logout_2': [1062, 591]
}
ACCOUNT = [
    ['trinhdiep.pie03@gmail.com', 'Quyendiep2002'],
    ['trinhdiep.pie03@gmail.com', 'Quyendiep2002'],
    ['trinhdiep.pie03@gmail.com', 'Quyendiep2002'],
    ['trinhdiep.pie03@gmail.com', 'Quyendiep2002']
]


def switch_acc(account):
    pag.hotkey('esc')
    pag.sleep(1)
    pag.click(POSITION['acc'])
    pag.sleep(1)
    pag.click(POSITION['logout'])
    pag.sleep(1)
    pag.click(POSITION['logout_2'])
    pag.sleep(10)
    login(account)


def login(account):
    pag.click(POSITION['login'])
    print('ok to launch browser')
    pag.sleep(2)
    while not pag.locateOnScreen(f'D:\\TOOL-PY\\Auto-Comments\\Auto-comment-Pyautogui\\image\\logintotiktok.png'):
        pag.sleep(1)
        print('waiting for launch browser 1')
    pag.click(POSITION['google_login'])
    pag.sleep(1)
    while not pag.locateOnScreen(f'D:\\TOOL-PY\\Auto-Comments\\Auto-comment-Pyautogui\\image\\account1.png'):
        pag.sleep(1)
        print('waiting for launch browser 2')
    pag.click(POSITION['user'])
    pag.sleep(1)
    while not pag.locateOnScreen(f'D:\\TOOL-PY\\Auto-Comments\\Auto-comment-Pyautogui\\image\\signin.png'):
        pag.sleep(1)
        print('waiting for launch browser 3')
    pag.sleep(1)
    pag.hotkey('ctrl', 'a')
    pag.typewrite(account[0])
    pag.sleep(0.5)
    pag.hotkey('enter')
    pag.sleep(1)
    pag.hotkey('ctrl', 'a')
    pag.typewrite(account[1])
    pag.sleep(0.5)
    pag.hotkey('enter')
    pag.sleep(10)


account = 0
comments = 'Xin Chao'
pag.click(POSITION['micro_edge'])
pag.sleep(3)
pag.typewrite('https://www.tiktok.com/')
pag.hotkey('enter')
pag.sleep(5)
pag.click(POSITION['video'])
pag.sleep(7)
count_cmt = 0
while True:
    count_cmt += 1
    pag.click(POSITION['comments'])
    pag.sleep(2)
    pag.typewrite(comments)
    pag.sleep(1)
    pag.hotkey('enter')
    pag.sleep(3)
    pag.click(POSITION['video'])
    pag.sleep(10)
    pag.press('down')
    pag.sleep(5)
    print(count_cmt)
    if count_cmt == 1:
        account += 1
        switch_acc(ACCOUNT[account])
