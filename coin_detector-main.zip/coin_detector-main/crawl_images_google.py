import bs4 #bs4
import requests
from selenium import webdriver #selenium
import os
import time
from selenium.webdriver.common.by import By

search_URL = "https://www.google.com/search?q=1+cent+australian+dollar,+australia+coin&sxsrf=APwXEdfHEhAq0vdza8ELNWBLVq1mWd2eUA:1679839821728&source=lnms&tbm=isch&sa=X&ved=2ahUKEwjl4-n-4vn9AhVfUGwGHaWqAjwQ_AUoAXoECAEQAw&biw=1283&bih=816&dpr=1"
name = '1cent'

chromePath="/home/duong/Downloads/chromedriver_linux64/chromedriver"
driver = webdriver.Chrome(chromePath)

#creating a directory to save images
folder_name = '/home/duong/Documents/coinNet/coin_recognize/datasets/' + name
if not os.path.isdir(folder_name):
    os.mkdir(folder_name)

def download_image(url, folder_name, num):
    respond = requests.get(url)
    if respond.status_code == 200:
        with open(os.path.join(folder_name, str(num)+".jpg"), 'wb') as file:
            file.write(respond.content)

driver.get(search_URL)

a = input("Waiting...")

driver.execute_script("window.scrollTo(0, 0);")

page_html = driver.page_source
pageSoup = bs4.BeautifulSoup(page_html, 'html.parser')
containers = pageSoup.findAll('div', {'class': "isv-r PNCib MSM1fd BUooTd"})

print(len(containers))

len_containers = len(containers)

for i in range(1, len_containers+1):
    if i % 25 == 0:
        continue
    # //*[@id="islrg"]/div[1]/div[1]/a[1]/div[1]/img
    xPath = """//*[@id="islrg"]/div[1]/div[%s]"""%(i)
    previewImageXPath = """//*[@id="islrg"]/div[1]/div[%s]/a[1]/div[1]/img"""%(i)
    previewImageElement = driver.find_element(By.XPATH, previewImageXPath)
    previewImageURL = previewImageElement.get_attribute("src")

    driver.find_element(By.XPATH, xPath).click()

    timeStarted = time.time()

    while True:
    # //*[@id="Sva75c"]/div/div/div[3]/div[2]/c-wiz/div/div[1]/div[1]/div[3]/div/a/img
        imageElement = driver.find_element(By.XPATH, """//*[@id="Sva75c"]/div[2]/div/div[2]/div[2]/div[2]/c-wiz/div/div[1]/div[2]/div[2]/div/a/img""")
        imageURL= imageElement.get_attribute('src')

        if imageURL != previewImageURL:
            #print("actual URL", imageURL)
            break

        else:
            #making a timeout if the full res image can't be loaded
            currentTime = time.time()

            if currentTime - timeStarted > 10:
                print("Timeout! Will download a lower resolution image and move onto the next one")
                break
    #Downloading image
    try:
        download_image(imageURL, folder_name, i)
        print("Downloaded element %s out of %s total. URL: %s" % (i, len_containers + 1, imageURL))
    except:
        print("Couldn't download an image %s, continuing downloading the next one"%(i))