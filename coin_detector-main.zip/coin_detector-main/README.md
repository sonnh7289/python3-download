# Coin Detector
Deploy an application that allows you to quickly look up coin information from a snapshot

1. Create your database with informations on 'coin_detector/coinnet_app/db_coin.py'
2. Prepare your dataset and save on 'coin_detector/coins/data'. 
On this directory, you must have 2 folders './back' and './front' represent each side of the coin
3. Adjust the parameters in config.ini
4. Run train.py to train
5. Run eval.py to see the result

If you want to deploy this project
1. Run 'coin_detector/coinnet_app/db_coin.py' to create database
2. Run main.py to deploy project on your server
