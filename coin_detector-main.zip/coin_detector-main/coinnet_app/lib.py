import json
import mysql.connector
from mysql.connector import errorcode
from coinnet_app.coinsql import CoinDatabase
from configparser import ConfigParser
import ast
from datetime import datetime
import pytz

tz = pytz.timezone("Asia/Ho_Chi_Minh")
config = ConfigParser()
config.read(r"./config.ini")

json_coin_path = r"./cat_to_name/cat_to_name_59.json"

# @config coin database
coinConfig = {
    'user'    : ast.literal_eval(config["DATABASE"]['user']),
    'password': ast.literal_eval(config["DATABASE"]['password']),
    'host'    : ast.literal_eval(config["DATABASE"]['host']),
    'db'      : ast.literal_eval(config["DATABASE"]['database']),
}
mydb = CoinDatabase(**coinConfig)
mydb.config = coinConfig