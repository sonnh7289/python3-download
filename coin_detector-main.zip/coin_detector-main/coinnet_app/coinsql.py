import mysql.connector
import json

class CoinDatabase:
    def __init__(self, host, user, password, db='crawl_beetoon', pool_size=5):
        self.config = {
            'user': user,
            'password': password,
            'host': host,
            'database': db,
            'raise_on_warnings': True,
            'pool_size': 5
        }
        self.mydatabase = mysql.connector.connect(**self.config)
        self.mycursor = self.mydatabase.cursor()
        self.insert_query = None
        self.select_query = None
        self.update_query = None

    def db_connection(self):
        while True:
            try:
                # Attempt to connect to the database
                self.mydatabase = mysql.connector.connect(**self.config)
                self.mycursor = self.mydatabase.cursor()
                return self.mydatabase, self.mycursor
            except mysql.connector.Error as err:
                continue
    
    def insert_data(self, query):
        self.mycursor.execute(query)
        self.mydatabase.commit()