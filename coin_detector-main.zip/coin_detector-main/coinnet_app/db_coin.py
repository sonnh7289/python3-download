from lib import *

# @read json data
def load_coin_data(json_coin_path):
    data = list()
    with open(json_coin_path, 'r', encoding="utf-8") as f:
        data = json.load(f)
    return data


def insert_coindata(coindata):
    mydb.db_connection()

    for coin in range(1, 60):
        now = datetime.now(tz)
        current_time = now.strftime("%Y/%m/%d %H:%M:%S")
        i = str(coin)
        coin_id = i
        coin_name = coindata[i]['name']
        coin_description = coindata[i]['description']
        coin_year = coindata[i]['basic_info']['Years']
        coin_desgin_date = coindata[i]['basic_info']['Design date']
        coin_value = coindata[i]['basic_info']['Value']
        coin_weight = coindata[i]['basic_info']['Weight']
        coin_diameter = coindata[i]['basic_info']['Diameter']
        coin_thickness = coindata[i]['basic_info']['Thickness']
        coin_shape = coindata[i]['basic_info']['Shape']
        coin_technique = coindata[i]['basic_info']['Technique']
        
        query = f'''INSERT INTO `coin`(`name`, `description`, `year`, `design_date`, `value`, `weight`, `diameter`, `thickness`, `shape`, `technique`, `created_at`, `updated_at`) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)'''
        mydb.mycursor.execute(query, (coin_name, coin_description, coin_year, coin_desgin_date,
                                        coin_value, coin_weight, coin_diameter,coin_thickness,
                                        coin_shape, coin_technique, current_time, current_time))
        mydb.mydatabase.commit()
        print(f"\n\n{i}:", coin_description)


'''
id
name = id.name
description = id.description
year = id.basic_info.Design date, Years 
value = id.basic_info.Value
weight = id.basic_info.Weight
diameter = id.basic_info.Diameter
thickness = id.basic_info.Thickness
shape = id.basic_info.Shape
technique = id.basic_info.Technique
other
'''

if __name__ == "__main__":
    insert_coindata(load_coin_data(json_coin_path))