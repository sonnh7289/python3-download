import sys
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
import numpy as np 
from PIL import Image
import matplotlib.pyplot as plt
import torchvision
from torchvision import datasets, models, transforms
import os
from glob import glob
import json

class BaseTransform():
    def __init__(self, resize, mean, std):
        self.resize = resize
        self.mean = mean
        self.std = std
        self.data_transforms = {
            'train': transforms.Compose([
                transforms.RandomResizedCrop(resize, scale=(0.5, 1.0)),
                transforms.RandomHorizontalFlip(),
                transforms.ToTensor(),
                transforms.Normalize(mean, std)
            ]),
            'val': transforms.Compose([
                transforms.Resize(resize),
                transforms.CenterCrop(resize),
                transforms.ToTensor(),
                transforms.Normalize(mean, std)
            ]),
        }
    def __call__(self):
        return self.data_transforms

class CoinDataset():
    def __init__(self, data_dir, transform=None):
        self.data_dir = data_dir
        self.transforms = transform

    def __call__(self):
        image_datasets = {x: datasets.ImageFolder(os.path.join(self.data_dir, x),
                                                  self.transforms[x])
                          for x in ['train', 'val']}
        dataloaders = {x: torch.utils.data.DataLoader(image_datasets[x], batch_size=5,
                                                      shuffle=True, num_workers=0)
                       for x in ['train', 'val']}
        dataset_sizes = {x: len(image_datasets[x]) for x in ['train', 'val']}
        class_names = image_datasets['train'].classes

        return dataloaders, dataset_sizes, class_names
