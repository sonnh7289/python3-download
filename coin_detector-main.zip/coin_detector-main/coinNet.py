'''
CoinSnap
'''
import os
import torch
import torch.nn as nn
import torchvision
from torchvision import models, datasets, transforms
from PIL import Image
import json
import numpy as np
import ast
import matplotlib.pyplot as plt
from src.utils.inference import Predictor, BaseTranform
from configparser import ConfigParser
from flask import Flask, jsonify, request, render_template
from flask_restful import Api, Resource
from coinnet_app.lib import *


# @load config
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
config = ConfigParser()
config.read("./config.ini")

# Classifers
num_class = int(config["DEFAULT"]['classes'])
class_names = ast.literal_eval(config['INFERENCE']['class_names'])
class_index = []

# Cat to name
cat_to_name = ast.literal_eval(config['INFERENCE']['cat_to_name'])
with open(cat_to_name, 'r') as f:
    data = json.load(f)
for name in class_names:
    class_index.append(data[name])

# Load back side model
b_model = models.resnet50(pretrained=True)
b_model = b_model.to(device)
num_ftrs = b_model.fc.in_features
b_model.fc = nn.Linear(num_ftrs, num_class)

# Load front side model
f_model = models.resnet50(pretrained=True)
f_model = f_model.to(device)
num_ftrs = f_model.fc.in_features
f_model.fc = nn.Linear(num_ftrs, num_class)

# Load checkpoint
back_path = ast.literal_eval(config["CHECKPOINT"]['b_checkpoint'])
front_path = ast.literal_eval(config["CHECKPOINT"]['f_checkpoint'])
b_checkpoint = torch.load(back_path, map_location=torch.device('cpu'))['model_state_dict']
f_checkpoint = torch.load(front_path, map_location=torch.device('cpu'))['model_state_dict']
b_model.load_state_dict(b_checkpoint)
b_model.eval()
f_model.load_state_dict(f_checkpoint)
f_model.eval()


# Prediction
predictor = Predictor(class_index)

# Transform parameters
resize = ast.literal_eval(config['PARAMETERS']['resize'])
mean = ast.literal_eval(config['PARAMETERS']['mean'])
std = ast.literal_eval(config['PARAMETERS']['std'])
transform = BaseTranform(resize, mean, std)

def coindetect(img, model):
    # img = Image.open(img)
    img_transformed = transform(img)
    img_transformed = img_transformed.unsqueeze_(0)
    out = model(img_transformed)
    result, score = predictor.predict_max(out)
    return result, np.max(score)

def coinSnap(b_img, f_img):
    b_predict_1, b_score1 = coindetect(b_img, b_model)
    b_predict_2, b_score2 = coindetect(f_img, b_model)
    b_result, f_result = None, None
    b_score, f_score = None, None

    if b_score1>b_score2:
        b_result = b_predict_1
        b_score = b_score1

        f_result, f_score = coindetect(f_img, f_model)
    elif b_score1<b_score2:
        b_result = b_predict_2
        b_score = b_score2

        f_result, f_score = coindetect(b_img, f_model)

    return b_result