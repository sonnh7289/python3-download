from coinApp import *

# Rest API
app = Flask(__name__, template_folder="template")
@app.route("/home", methods=["POST", "GET"])
def get_coin_predict():
    # b_img = request.form.get("backside")
    b_img = request.files['backside']
    b_img.save('./test/backside.jpg')
    b_image = Image.open('./test/backside.jpg')

    f_img = request.files['frontside']
    f_img.save('./test/frontside.jpg')
    f_image = Image.open('./test/frontside.jpg')
    data = get_coin_snap(b_image, f_image)
    return jsonify(data)

@app.route("/coin/<int:coin_id>", methods = ["GET"])
def coin_id_info(coin_id):
    data = get_coin_id_info(coin_id)
    return jsonify({"Message":data})

@app.route("/register", methods = ["GET", "POST"])
def user_register():
    username = request.form.get('username')
    email = request.form.get('email')
    password = request.form.get('password')
    if request.method == "GET":
        data = dict()
        data['username'] = username
        data['email'] = email
        data['password'] = password
        return jsonify({"Message":data})
    else:
        data = insert_user_inf(username,email, password)
        return jsonify({"Message":data})

@app.route("/login", methods = ["GET", "POST"])
def user_login():
    username = request.form.get('username')
    email = request.form.get('email')
    password = request.form.get('password')
    if request.method == "GET":
        data = dict()
        data['username'] = username
        data['email'] = email
        data['password'] = password
        return jsonify({"Message":data})
    else:
        data = check_user_login(username,email, password)
        return jsonify({"Message":data})

# User logout
@app.route("/logout", methods=["POST"])
def user_logout():
    username = request.form.get('username')
    message = check_user_logout(username)
    return jsonify({"Message":message})

@app.route("/user/change-password", methods=["PUT"])
def change_password():
    username = request.form.get("username")
    old_password = request.form.get("old_password")
    new_password = request.form.get("new_password")

    data = user_change_password(username, old_password, new_password)
    return data

@app.route("/favorite/<int:coin_id>", methods=["POST"])
def add_favorite_coin(coin_id):
    username = request.form.get("username")
    is_favorite = request.form.get("is_favorite")
    if is_favorite == "1":
        data = user_add_favortite_coin(username,is_favorite, coin_id)
    if is_favorite == "0":
        data = user_remove_favorite_coin(username,is_favorite, coin_id)
    return jsonify({"Message":data})

@app.route("/favorite", methods=["GET"])
def get_favorite_coin():
    username = request.form.get("username")
    data = user_get_favorite_coin(username)
    return jsonify({"Message":data})

if __name__ == "__main__":
    app.run(host='0.0.0.0',port=5689,debug=True)