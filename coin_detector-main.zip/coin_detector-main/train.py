import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim import lr_scheduler
import torch.nn.functional as F
import torchvision
from torchvision import datasets, models, transforms
import matplotlib.pyplot as plt
import numpy as np
import ast
from src.utils.util import params_to_update
from src.models.train import coinNet
from src.data.dataset import CoinDataset, BaseTransform
from configparser import ConfigParser

config = ConfigParser()
config.read("config.ini")

## DEFAULT SETTINGS
# Model
model_mode = str(config["DEFAULT"]['model'])
train_mode = str(config["DEFAULT"]['mode'])
save_path = ast.literal_eval(config["DEFAULT"]['save_path'])
# Classifers
num_class = int(config["DEFAULT"]['classes'])
data_dir = ast.literal_eval(config["DEFAULT"]['data'])

# Hyperparameters
num_epochs = ast.literal_eval(config["DEFAULT"]['epochs'])

# CUDA
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

# Transform parameters
resize = ast.literal_eval(config['PARAMETERS']['resize'])
mean = ast.literal_eval(config['PARAMETERS']['mean'])
std = ast.literal_eval(config['PARAMETERS']['std'])

# Plot transform images
def imshow(inp, title):
    """Imshow for Tensor."""
    inp = inp.numpy().transpose((1, 2, 0))
    inp = std * inp + mean
    inp = np.clip(inp, 0, 1)
    plt.imshow(inp)
    plt.title(title)
    plt.show()

# Transforms
data_transform = BaseTransform(resize, mean, std)

# Load dataset
coindataset = CoinDataset(data_dir=data_dir, transform=data_transform.data_transforms)
dataloaders, dataset_sizes, class_names = coindataset()
# print(class_names)
config["INFERENCE"] ={
    'class_names' : class_names
}
with open("config.ini", 'w') as f:
    config.write(f)

# One hot encoding
class_names = [int(x) for x in class_names]
class_names = torch.tensor(class_names) -1
class_names = F.one_hot(class_names, num_classes=num_class)

# Show plot images
inputs, classes = next(iter(dataloaders['train']))
# print(inputs.shape, len(class_names))
out = torchvision.utils.make_grid(inputs)
# imshow(out, title=[class_names[x] for x in classes])

def train_mode(coin_net, train_mode='finetune'):
    if train_mode=='finetune':
        params1, params2, params3 = params_to_update(coin_net)
        return params1, params2, params3

    elif train_mode=='pretrain':
        for param in coin_net.parameters():
            param.requires_grad = False

def vgg16():
    coin_net = models.vgg16(pretrained=True)
    params1, params2, params3 = params_to_update(coin_net)
    coin_net.classifier[6] = nn.Linear(in_features=4096, out_features=num_class)
    coin_net = coin_net.to(device)
    optimizer_conv = optim.SGD([
        {'params': params1, 'lr': 1e-4},
        {'params': params2, 'lr': 5e-4},
        {'params': params3, 'lr': 1e-3},
    ], momentum=0.9)
    return coin_net, optimizer_conv

def resnet50():
    coin_net = models.resnet50(pretrained=True)
    for param in coin_net.parameters():
        param.requires_grad = False

    num_ftrs = coin_net.fc.in_features
    coin_net.fc = nn.Linear(num_ftrs, num_class)
    coin_net = coin_net.to(device)

    optimizer_conv = optim.SGD(coin_net.fc.parameters(), lr=0.001, momentum=0.9)
    return coin_net, optimizer_conv

def train(model_train):
    if model_train == 'vgg16':
        coin_net, optimizer_conv = vgg16()
        return coin_net, optimizer_conv
    elif model_train == 'resnet50':
        coin_net, optimizer_conv = resnet50()
        return coin_net, optimizer_conv


def main():
    coin_net, optimizer_conv = train(model_train=model_mode)

    criterion = nn.CrossEntropyLoss()

    exp_lr_scheduler = lr_scheduler.StepLR(optimizer_conv, step_size=7, gamma=0.1)
    coin_net_model = coinNet(coin_net, model_mode, save_path, device, dataloaders, dataset_sizes, criterion,
                             optimizer_conv, exp_lr_scheduler, num_epochs=num_epochs)
    model_conv = coin_net_model.train_model()
    print('Finished Training')

if __name__ == "__main__":
    main()