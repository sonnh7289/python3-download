package com.example.androidhealthcareproject.user_manager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
