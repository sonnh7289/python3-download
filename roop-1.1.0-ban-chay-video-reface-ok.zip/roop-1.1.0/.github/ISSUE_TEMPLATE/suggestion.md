---
name: Suggestion
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

**Describe your suggestion**
A clear and concise description of what you want to happen.
