CREATE DATABASE MANGASOCIAL;
USE MANGASOCIAL;

CREATE TABLE USERS (
	id_user int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
	email varchar(250) NOT NULL UNIQUE KEY,
	password varchar(250) NOT NULL,
	time_register varchar(250) NOT NULL
);

CREATE TABLE PROFILES (
	id_user int(11) NOT NULL,
	name_user varchar(250) NOT NULL UNIQUE KEY,
	avatar_user varchar(250),
	participation_time varchar(250),
	number_reads int(11),
	number_comments int(11),
	year_birth int(4),
	sex varchar(11),
	introduction varchar(500),
	FOREIGN KEY (id_user) REFERENCES USERS(id_user)
);

CREATE TABLE MANGA (
	id_manga varchar(250) NOT NULL PRIMARY KEY,
	name_manga varchar(250) NOT NULL UNIQUE KEY,
	cover_image varchar(200),
	author varchar(100),
	status varchar(250),
	chapter_number int(11),
	views_manga int(11),
	likes int(11),
	followers int(11),
	time_update varchar(250), 
	description varchar(1000)
);

CREATE TABLE CHAPTER (
	id_chapter varchar(250) NOT NULL PRIMARY KEY,
	id_manga varchar(250) NOT NULL,
	views_chapter int(11),
	time_upload varchar(250),
	FOREIGN KEY (id_manga) REFERENCES MANGA(id_manga)
);

CREATE TABLE COMMENT (
	id_comment varchar(250) PRIMARY KEY,
	id_user int(11) NOT NULL,
	id_chapter varchar(250) NOT NULL,
	content varchar(1000) NOT NULL,
	time_comment varchar(250) NOT NULL,
	likes_comment int(11),
	FOREIGN KEY (id_user) REFERENCES USERS(id_user),
	FOREIGN KEY (id_chapter) REFERENCES CHAPTER(id_chapter)
);

CREATE TABLE HISTORY (
	id_user int(11) NOT NULL,
	id_chapter varchar(250) NOT NULL,
	time_read varchar(250) NOT NULL,
	FOREIGN KEY (id_user) REFERENCES USERS(id_user),
	FOREIGN KEY (id_chapter) REFERENCES CHAPTER(id_chapter)
);