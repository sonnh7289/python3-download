from flask import Flask, request, session, jsonify, redirect, url_for
from flask_mysqldb import MySQL
from flask_cors import CORS
from itsdangerous import URLSafeTimedSerializer
from werkzeug.security import check_password_hash, generate_password_hash
from flask_jwt_extended import JWTManager, create_access_token, create_refresh_token, get_jwt_identity, jwt_required
from flask_login import login_user, login_required, logout_user, current_user
from flask_mail import *
import MySQLdb.cursors
import re
from datetime import datetime, timedelta

app = Flask(__name__)
app.secret_key = "d5e6d7g8h9z1a2b3c4g8h9z1a2b3c4d5e6d5e6d7g8h9z"

app.config["MYSQL_HOST"] = "localhost"
app.config["MYSQL_USER"] = "root"
app.config["MYSQL_PASSWORD"] = ""
app.config["MYSQL_DB"] = "mangasocial"

app.config["MAIL_SERVER"] = "smtp.gmail.com"
app.config["MAIL_PORT"] = 465
app.config["MAIL_USERNAME"] = "buikhanhtoan_t64@hus.edu.vn"
app.config["MAIL_PASSWORD"] = "mpkehnwnmcziryqs"
app.config["MAIL_USE_TLS"] = False
app.config["MAIL_USE_SSL"] = True
app.config["SECURITY_PASSWORD_SALT"] = "d5e6d7g8h9w6rq5w6r7z8x7z8x9c"

app.config["JWT_SECRET_KEY"] = "1ac4d5e6d5e2s6d7g8h9w63d49c"

mysql = MySQL(app)
jwt = JWTManager(app)
mail= Mail(app)
CORS(app)
secret = URLSafeTimedSerializer(app.config["SECRET_KEY"])

def convert_time(time_register):
	time_now = datetime.now().strftime("%H:%M:%S %d-%m-%Y")
	register_date = datetime.strptime(time_register, "%H:%M:%S %d-%m-%Y")
	current_date = datetime.strptime(time_now, "%H:%M:%S %d-%m-%Y")

	participation_time = current_date - register_date
	if participation_time < timedelta(minutes=1):
		time_in_seconds = participation_time.seconds
		time = f"{time_in_seconds} giây trước"
	elif participation_time < timedelta(hours=1):
		time_in_minutes = participation_time.seconds // 60
		time = f"{time_in_minutes} phút trước"
	elif participation_time < timedelta(days=1):
		time_in_hours = participation_time.seconds // 3600
		time = f"{time_in_hours} giờ trước"
	elif participation_time < timedelta(days=365):
		time_in_days = participation_time.days
		time = f"{time_in_days} ngày trước"
	else:
		time_in_years = participation_time.days // 365
		time = f"{time_in_years} năm trước"
	return time