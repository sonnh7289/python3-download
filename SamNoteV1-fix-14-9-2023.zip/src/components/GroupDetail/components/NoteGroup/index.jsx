import React from 'react';
import PropTypes from 'prop-types';

NoteGroup.propTypes = {
    
};

function NoteGroup(props) {
    return (
        <div>
            
        </div>
    );
}

export default NoteGroup;