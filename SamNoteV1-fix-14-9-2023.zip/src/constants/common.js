// export const STATIC_HOST = "http://14.225.7.179:18011/"
export const STATIC_HOST = "https://lhvn.online/";
