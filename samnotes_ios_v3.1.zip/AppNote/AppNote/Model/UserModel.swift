//
//  UserNoteModel.swift
//  AppNote
//
//  Created by Vũ Ngọc Lâm on 10/10/2023.
//

import Foundation

// MARK: - Welcome
struct UserModel: Codable {
    let jwt, message: String
    let status: Int
    let user: User
}

// MARK: - User
struct User: Codable {
    let avarta, avtProfile: String
    let dfColor: DfColor
    let dfScreen, gmail: String
    let id: Int
    let name: String
    let password2: JSONNull?
    let statesLogin: Bool

    enum CodingKeys: String, CodingKey {
        case avarta = "Avarta"
        case avtProfile = "AvtProfile"
        case dfColor = "df_color"
        case dfScreen = "df_screen"
        case gmail, id, name
        case password2 = "password_2"
        case statesLogin
    }
}

// MARK: - DfColor
struct DfColor: Codable {
    let a: Double
    let b, g, r: Int
}

// MARK: - Encode/decode helpers

class JSONNull: Codable, Hashable {

    public static func == (lhs: JSONNull, rhs: JSONNull) -> Bool {
        return true
    }

    public var hashValue: Int {
        return 0
    }

    public init() {}

    public required init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if !container.decodeNil() {
            throw DecodingError.typeMismatch(JSONNull.self, DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Wrong type for JSONNull"))
        }
    }

    public func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        try container.encodeNil()
    }
}
