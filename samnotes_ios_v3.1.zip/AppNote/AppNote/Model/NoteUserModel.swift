//
//  NoteUser.swift
//  AppNote
//
//  Created by Vũ Ngọc Lâm on 07/10/2023.
//
// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let welcome = try? JSONDecoder().decode(Welcome.self, from: jsonData)

import Foundation

// MARK: - Welcome
struct NoteUserModel: Codable {
    let notes: [Notes]
}

// MARK: - Note
struct Notes: Codable {
    let color: Color
    let createAt, data: String
    let doneNote: Int
    let dueAt: JSONNull?
    let idNote, idUser: Int
    let linkNoteShare, lock: JSONNull?
    let notePublic, pinned: Int
    let remindAt: JSONNull?
    let title, type, updateAt: String
}
// MARK: - Color
struct Color: Codable {
    let a: Float
    let b, g, r: Int
}

// MARK: - Encode/decode helpers

//class JSONNull: Codable, Hashable {
//
//    public static func == (lhs: JSONNull, rhs: JSONNull) -> Bool {
//        return true
//    }
//
//    public var hashValue: Int {
//        return 0
//    }
//
//    public init() {}
//
//    public required init(from decoder: Decoder) throws {
//        let container = try decoder.singleValueContainer()
//        if !container.decodeNil() {
//            throw DecodingError.typeMismatch(JSONNull.self, DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Wrong type for JSONNull"))
//        }
//    }
//
//    public func encode(to encoder: Encoder) throws {
//        var container = encoder.singleValueContainer()
//        try container.encodeNil()
//    }
//}





/*import Foundation

struct NoteUserModel: Codable {
    let notes: [Notes]
}

// MARK: - Note
struct Notes: Codable {
    let color: Color
    let createAt, data: String
    let doneNote: Int
    let dueAt: JSONNull?
    let idNote, idUser: Int
    let linkNoteShare, lock: JSONNull?
    let metaData: String
    let notePublic, pinned: Int
    let remindAt: JSONNull?
    let title: String
    let type: TypeEnum
    let updateAt: String
}

// MARK: - Color
struct Color: Codable {
    let a: Float
    let b, g, r: Int
}

enum TypeEnum: String, Codable {
    case screenshot = "screenshot"
}

// MARK: - Encode/decode helpers

class JSONNull: Codable, Hashable {

    public static func == (lhs: JSONNull, rhs: JSONNull) -> Bool {
        return true
    }

    public var hashValue: Int {
        return 0
    }

    public init() {}

    public required init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if !container.decodeNil() {
            throw DecodingError.typeMismatch(JSONNull.self, DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Wrong type for JSONNull"))
        }
    }

    public func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        try container.encodeNil()
    }
}
*/
