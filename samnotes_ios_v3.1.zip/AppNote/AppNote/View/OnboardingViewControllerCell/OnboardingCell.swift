//
//  OnboardingCell.swift
//  Note_IOS_V2.0
//
//  Created by Vũ Ngọc Lâm on 27/09/2023.
//

import UIKit

class OnboardingCell: UICollectionViewCell {

    @IBOutlet weak var artImageView: UIImageView!
    @IBOutlet weak var headingLable: UILabel!
    @IBOutlet weak var subHeadingLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

}
