//
//  HomePageCollectionViewCell.swift
//  AppNote
//
//  Created by Vũ Ngọc Lâm on 07/10/2023.
//

import UIKit

class HomePageCollectionViewCell: UICollectionViewCell {
    
    public static var identifiler: String {
        get {
            return "HomePageCollectionViewCell"
        }
    }
    public static func register() -> UINib {
        UINib(nibName: "HomePageCollectionViewCell", bundle: nil)
    }
    
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblSubText: UILabel!
    @IBOutlet weak var btnShare: UIButton!
    @IBOutlet weak var viewBtn: UIView!
    
    var viewSave = UIView()
    var imgSave = UIImageView()

    override func awakeFromNib() {
        super.awakeFromNib()
        LblTitle()
        BtnShare()
        ViewButton()
    }
    override init(frame: CGRect) {
        super .init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        ViewSave()
        ImgSave()
    }
    
    func ViewSave() {
        viewSave.layer.cornerRadius = UIScreen.main.bounds.height * 25 / 932
        viewSave.layer.maskedCorners = [.layerMinXMaxYCorner]
        addSubview(viewSave)
        viewSave.backgroundColor = .gray
        viewSave.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            viewSave.widthAnchor.constraint(equalTo: viewSave.heightAnchor, multiplier: 43 / 42),
            viewSave.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 43 / 382),
            viewSave.trailingAnchor.constraint(equalTo: trailingAnchor),
            viewSave.topAnchor.constraint(equalTo: topAnchor),
        ])
    }
    func ImgSave() {
        imgSave.image = UIImage(named: "save")
        addSubview(imgSave)
        imgSave.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            imgSave.widthAnchor.constraint(equalTo: imgSave.heightAnchor, multiplier: 18 / 18),
            imgSave.widthAnchor.constraint(equalTo: viewSave.widthAnchor, multiplier: 18 / 43),
            imgSave.centerXAnchor.constraint(equalTo: viewSave.centerXAnchor),
            imgSave.centerYAnchor.constraint(equalTo: viewSave.centerYAnchor)
        ])
    }
    func LblTitle() {
        lblTitle?.textColor = UIColor(red: 0.04, green: 0.04, blue: 0.04, alpha: 1.00)
        lblTitle?.font = UIFont(name: "Poppins-SemiBold", size: 14.0)
    }
    func ViewButton() {
        viewBtn.layer.cornerRadius = UIScreen.main.bounds.height * 29 / 2 / 932
        viewBtn.layer.shadowColor = UIColor(red: 0.012, green: 0.016, blue: 0.016, alpha: 0.5).cgColor
        viewBtn.layer.shadowOffset = CGSize(width: 0, height: 3)
        viewBtn.layer.shadowRadius = 2
        viewBtn.layer.shadowOpacity = 0.5
        viewBtn.layer.masksToBounds = false
        //viewBtn.clipsToBounds = true
    }
    func BtnShare() {
        btnShare.translatesAutoresizingMaskIntoConstraints = false
        btnShare.setTitle("Shared to 10 peoples", for: .normal)
        btnShare.titleLabel?.font = UIFont(name: "Poppins-Regular", size: 8.0)
        btnShare.setTitleColor(UIColor(red: 0.04, green: 0.04, blue: 0.04, alpha: 1.00), for: .normal)
        let image = UIImage(named: "shared")
        btnShare.setImage(image, for: .normal)
        var configuration = UIButton.Configuration.filled()
        let spacing: CGFloat = UIScreen.main.bounds.height * 20 / 932
        configuration.imagePadding = spacing
        configuration.baseBackgroundColor = .clear
        configuration.titleAlignment = .center
        btnShare.configuration = configuration
    }
    
    func setupCell(viewModel: NoteCollectionCellViewModel) {
      //  print("statusss: \(viewModel.statusButton)")
        self.round(UIScreen.main.bounds.height * 30 / 932)
        self.lblTitle.text = viewModel.title
        self.lblSubText.text = viewModel.subNote
        let r = Float(viewModel.r) / Float(256)
        let g = Float(viewModel.g) / Float(256)
        let b = Float(viewModel.b) / Float(256)
        let a = Float(viewModel.a)
        self.backgroundColor = UIColor(red: CGFloat(r),
                                       green: CGFloat(g),
                                       blue: CGFloat(b),
                                       alpha: CGFloat(a))
        switch viewModel.r {
        case 252:
            viewBtn.backgroundColor = AppConstant.btnVang
            viewSave.backgroundColor = AppConstant.btnVang
        case 249:
            viewBtn.backgroundColor = AppConstant.btnHong
            viewSave.backgroundColor = AppConstant.btnHong
        case 220:
            viewBtn.backgroundColor = AppConstant.btnLam
            viewSave.backgroundColor = AppConstant.btnLam
        default:
            viewBtn.backgroundColor = AppConstant.btnTim
            viewSave.backgroundColor = AppConstant.btnTim
        }
    }
    func setHeight(viewModel: NoteCollectionCellViewModel) -> CGFloat {
        let screenWidth = UIScreen.main.bounds.width
        let screenHeight = UIScreen.main.bounds.height
       // let noteData = viewModel.subNote
        let titleFont = UIFont(name: "Poppins-SemiBold", size: 14.0)
        let titleText = viewModel.title
        let titleMaxWidth = screenWidth - 109 / 430
        let titleSize = (titleText as NSString).boundingRect(with: CGSize(width: titleMaxWidth, height: .greatestFiniteMagnitude), options: .usesLineFragmentOrigin, attributes: [NSAttributedString.Key.font: titleFont!], context: nil).size
        let titleHeight = titleSize.height
//        let titleWidth = titleSize.width
        let noteFont = UIFont(name: "Poppins-SemiBold", size: 10.0)
        let noteText = viewModel.subNote
        let noteMaxWidth = screenWidth * 349 / 430
        let noteSize = (noteText as NSString).boundingRect(with: CGSize(width: noteMaxWidth, height: .greatestFiniteMagnitude), options: .usesLineFragmentOrigin, attributes: [NSAttributedString.Key.font: noteFont!], context: nil).size
        let noteHeight = noteSize.height
        let buttonHeight = screenHeight * 105 / 932
//        var cellnotecon = 0.0
//        let noteFontcon = UIFont.systemFont(ofSize: 10)
//        let noteMaxWidthcon = screenWidth - 352 / 430
//        for notecon in object.checkList
//        {
//            let noteSizecon = (notecon.text as NSString).boundingRect(with: CGSize(width: noteMaxWidthcon, height: .greatestFiniteMagnitude), options: .usesLineFragmentOrigin, attributes: [NSAttributedString.Key.font: noteFontcon], context: nil).size
//            let noteHeightcon = noteSizecon.height + 15
//            cellnotecon += noteHeightcon
//        }
        let cellHeight = titleHeight  + buttonHeight + noteHeight
        return cellHeight
    }
}
