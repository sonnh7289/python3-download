//
//  HomePageViewModel.swift
//  AppNote
//
//  Created by Vũ Ngọc Lâm on 07/10/2023.
//

import Foundation

class HomeViewModel {
    
    var isLoading: Observable<Bool> = Observable(false)
    //var cellDataSource: Observable<[Notes]> = Observable(nil)
    var cellDataSource: Observable<[NoteCollectionCellViewModel]> = Observable(nil)
    var dataSource: NoteUserModel?
    var colorNote: Color?
    
    func showAvatar(completion: @escaping (Data?) -> Void) {
        if let url = URL(string: AppConstant.linkAvatar!) {
            URLSession.shared.dataTask(with: url) { (data, response, error) in
                if let error = error {
                    print("Error: \(error.localizedDescription)")
                    completion(nil)
                } else if let data = data {
                    completion(data)
                } else {
                    print("No data received.")
                    completion(nil)
                }
            }.resume()
        } else {
            print("Invalid URL")
            completion(nil)
        }
    }
    func numberOfSections() -> Int {
        return 1
    }
    
    func numberOfRows(in section: Int) -> Int {
        self.dataSource?.notes.count ?? 0
    }
    
    func getData() {
        if isLoading.value ?? true {
            return
        }
        isLoading.value = true
        APICaller.getAllNotes { [weak self] result in
            self?.isLoading.value = false
            switch result {
            case .success(let data):
                //print("Total Notes: \(data.notes.count)")
                self?.dataSource = data
                self?.mapCellData()
            case .failure(let error):
                print(error)
            }
        }
    }
    
    func mapCellData() {
        //self.cellDataSource.value = self.dataSource?.notes ?? []
        self.cellDataSource.value  = self.dataSource?.notes.compactMap({NoteCollectionCellViewModel(note: $0)})
    }
    
    func getNoteTitle(_ note: Notes) -> String {
        return note.title
    }
    
    func getSubNote(_ note: Notes) -> String {
        return note.data
    }
    
    func getColorR(_ colorNote: Notes) -> Int {
        return colorNote.color.r
    }
    
    func getColorG(_ colorNote: Notes) -> Int {
        return colorNote.color.g
    }
    
    func getColorB(_ colorNote: Notes) -> Int {
        return colorNote.color.b
    }
    
    func getColorA(_ colorNote: Notes) -> Float {
        return colorNote.color.a
    }
    func getTotalNote() -> Int {
        return self.dataSource?.notes.count ?? 0
    }
}
