//
//  NoteCollectionCellViewModel.swift
//  AppNote
//
//  Created by Vũ Ngọc Lâm on 10/10/2023.
//

import Foundation

class NoteCollectionCellViewModel {
    
    var title: String
    var subNote: String
 //   var statusButton: String
   // var titleButton: String
    var r: Int
    var g: Int
    var b: Int
    var a: Float
    
    init(note: Notes) {
        self.title = note.title
        self.subNote = note.data
     //   self.statusButton = note.linkNoteShare
//        self.titleButton = note.linkNoteShare ??
        self.r = note.color.r
        self.g = note.color.g
        self.b = note.color.b
        self.a = note.color.a
    }
}
