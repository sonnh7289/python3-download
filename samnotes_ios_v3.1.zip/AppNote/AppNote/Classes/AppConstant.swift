//
//  AppConstant.swift
//  AppNote
//
//  Created by Vũ Ngọc Lâm on 10/10/2023.
//

import Foundation
import UIKit

struct AppConstant {
    static let vang: UIColor = UIColor(red: CGFloat(Float(254) / Float(256)),
                                       green: CGFloat(Float(245) / Float(256)),
                                       blue: CGFloat(Float(203) / Float(256)),
                                       alpha: 1)
    static let btnVang: UIColor = UIColor(red: CGFloat(Float(254) / Float(256)),
                                          green: CGFloat(Float(202) / Float(256)),
                                          blue: CGFloat(Float(70) / Float(256)),
                                          alpha: 1)
    static let hong: UIColor = UIColor(red: CGFloat(Float(255) / Float(256)),
                                       green: CGFloat(Float(221) / Float(256)),
                                       blue: CGFloat(Float(237) / Float(256)),
                                       alpha: 1)
    static let btnHong: UIColor = UIColor(red: CGFloat(Float(255) / Float(256)),
                                          green: CGFloat(Float(144) / Float(256)),
                                          blue: CGFloat(Float(196) / Float(256)),
                                          alpha: 1)
    static let lam: UIColor = UIColor(red: CGFloat(Float(216) / Float(256)),
                                      green: CGFloat(Float(236) / Float(256)),
                                      blue: CGFloat(Float(255) / Float(256)),
                                      alpha: 1)
    static let btnLam: UIColor = UIColor(red: CGFloat(Float(171) / Float(256)),
                                         green: CGFloat(Float(211) / Float(256)),
                                         blue: CGFloat(Float(249) / Float(256)),
                                         alpha: 1)
    static let tim: UIColor = UIColor(red: CGFloat(Float(225) / Float(256)),
                                      green: CGFloat(Float(202) / Float(256)),
                                      blue: CGFloat(Float(250) / Float(256)),
                                      alpha: 1)
    static let btnTim: UIColor = UIColor(red: CGFloat(Float(212) / Float(256)),
                                         green: CGFloat(Float(180) / Float(256)),
                                         blue: CGFloat(Float(247) / Float(256)),
                                         alpha: 1)
    static let art1 = UIImage(named: "image1")
    static let art2 = UIImage(named: "image2")
    static let art3 = UIImage(named: "image3")
    static let art4 = UIImage(named: "image4")
    static let art5 = UIImage(named: "image5")
    
    static let page = UIImage(named: "page")
    static let pageSelected = UIImage(named: "pageSelected")
    
    static let mainScreen = UIScreen.main.bounds.height
    
    static var userId: Int? {
        get { UserDefaults.standard.value(forKey: "userId") as? Int }
        set {
            if newValue == nil {
                UserDefaults.standard.removeObject(forKey: "userId")
                UserDefaults.standard.synchronize()
            } else {
                UserDefaults.standard.setValue(newValue, forKey: "userId")
            }
        }
    }
    static var linkAvatar: String? {
        get { UserDefaults.standard.value(forKey: "linkAvatar") as? String }
        set {
            if newValue == nil {
                UserDefaults.standard.removeObject(forKey: "linkAvatar")
                UserDefaults.standard.synchronize()
            } else {
                UserDefaults.standard.setValue(newValue, forKey: "linkAvatar")
            }
        }
    }
    static func logout() {
        userId = nil
    }
    static func saveUser(model: LoginModel) {
        userId = model.user?.id
        linkAvatar = model.user?.Avarta
    }
}
extension UserDefaults {
    func object<T: Codable>(_ type: T.Type, with key: String, usingDecoder decoder: JSONDecoder = JSONDecoder()) -> T? {
        guard let data = self.value(forKey: key) as? Data else { return nil }
        return try? decoder.decode(type.self, from: data)
    }
    
    func set<T: Codable>(object: T, forKey key: String, usingEncoder encoder: JSONEncoder = JSONEncoder()) {
        let data = try? encoder.encode(object)
        self.set(data, forKey: key)
    }
}
