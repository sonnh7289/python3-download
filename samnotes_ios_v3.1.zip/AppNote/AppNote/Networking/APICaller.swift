//
//  APICaller.swift
//  AppNote
//
//  Created by Vũ Ngọc Lâm on 07/10/2023.
//

import Foundation

class APICaller {
    
    enum NetworkError: Error {
        case urlError
        case canNotParseData
    }
    
    static func getAllNotes(
        completionHandler: @escaping (_ result: Result<NoteUserModel,NetworkError>) -> Void ) {
            let urlString = NetworkConstant.shared.serverAddress + String(NetworkConstant.shared.idkey)
            //print("url: \(urlString)")
            guard let url = URL(string: urlString) else {
                completionHandler(.failure(.urlError))
                return
            }
            
            URLSession.shared.dataTask(with: url) { dataResponse, urlResponse, error in
                if error == nil,
                   let data = dataResponse,
                   let resultData = try? JSONDecoder().decode(NoteUserModel.self,
                                                              from: data) {
                    completionHandler(.success(resultData))
                } else {
                    completionHandler(.failure(.canNotParseData))
                }
            }.resume()
    }
}
