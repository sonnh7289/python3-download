//
//  NetworkConstant.swift
//  AppNote
//
//  Created by Vũ Ngọc Lâm on 07/10/2023.
//

import Foundation

class NetworkConstant {
    
    public static var shared: NetworkConstant = NetworkConstant()
    
    private init() {
        
    }
    
    public var apiKey: String {
        get {
            return ""
        }
    }
    public var idkey: Int {
        get {
            return AppConstant.userId ?? 10
        }
    }
    public var serverAddress: String {
        get {
            return "https://lhvn.online/notes/"
        }
    }
    
    public var imageServerAddress: String {
        get {
            return ""
        }
    }
}
