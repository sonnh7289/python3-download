//
//  LoginServiceConfiguration.swift
//  Note_IOS_V2.0
//
//  Created by Vũ Ngọc Lâm on 29/09/2023.
//

import Foundation

enum LoginServiceConfiguration {
    case Login(user_name: String, password: String)
}

extension LoginServiceConfiguration: Configuration {
    var baseURL: String {
        switch self {
        case .Login:
            return Constant.Server.baseAPIURL
        }
    }
    
    var path: String {
        switch self {
        case .Login:
            return "login"
        }
    }
    
    var method: HTTPMethod {
        switch self {
        case .Login:
            return .post
        }
    }
    
    var task: Task {
        switch self {
        case .Login(let user_name, let password):
            let parameters = [
                "user_name": user_name,
                "password": password]
            return .requestParameters(parameters: parameters)
        }
    }
    
    var headers: [String : String]? {
        switch self {
        case .Login:
            return [:]
        }
    }
    
    var data: Data? {
        switch self {
        case .Login:
            return nil
        }
    }
}
