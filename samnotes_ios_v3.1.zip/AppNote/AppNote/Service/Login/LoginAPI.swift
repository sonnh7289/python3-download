//
//  LoginAPI.swift
//  Note_IOS_V2.0
//
//  Created by Vũ Ngọc Lâm on 29/09/2023.
//

import Foundation

class LoginAPI: BaseAPI<LoginServiceConfiguration> {
    static let shared = LoginAPI()
    
    func Login(user_name: String,
               password: String,
               completionHandler: @escaping (Result<LoginModel, ServiceError>) -> Void) {
        fetchData(configuration: .Login(user_name: user_name,
                                        password: password),
                  responseType: LoginModel.self) { result in
            completionHandler(result)
        }
    }
}
