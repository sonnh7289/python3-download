//
//  HomePageViewController+CollectionView.swift
//  AppNote
//
//  Created by Vũ Ngọc Lâm on 07/10/2023.
//

import Foundation
import UIKit

extension HomePageViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func setupCollectionView() {
//        self.collectionHome.delegate = self
//        self.collectionHome.dataSource = self
        regisiterCells()
        collectionHome.backgroundColor = .clear
    }
    
    func regisiterCells() {
       // collectionHome.register(UINib(nibName: "HomePageCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "HomePageCollectionViewCell")
        collectionHome.register(HomePageCollectionViewCell.register(),
                                forCellWithReuseIdentifier: HomePageCollectionViewCell.identifiler)
    }
    
    func reloadCollectionView() {
        DispatchQueue.main.async {
            self.collectionHome.reloadData()
        }
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
       return viewModel.numberOfSections()
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewModel.numberOfRows(in: section)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: HomePageCollectionViewCell.identifiler , for: indexPath) as? HomePageCollectionViewCell else {
            return UICollectionViewCell()
        }
        let cellViewModel = cellDataSource[indexPath.row]
        cell.setupCell(viewModel: cellViewModel)
        return cell
    }
    
}

extension HomePageViewController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return UIScreen.main.bounds.size.height * 20 / 932
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: HomePageCollectionViewCell.identifiler , for: indexPath) as? HomePageCollectionViewCell else {
            return CGSize(width: collectionHome.bounds.width,
                          height: collectionHome.bounds.height / 5)
        }
        let cellViewModel = cellDataSource[indexPath.row]
        return CGSize(width: collectionHome.bounds.width,
                      height: cell.setHeight(viewModel: cellViewModel))
    }
    
}
