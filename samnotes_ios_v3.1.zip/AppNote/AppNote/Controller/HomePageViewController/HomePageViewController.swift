//
//  HomePageViewController.swift
//  AppNote
//
//  Created by Vũ Ngọc Lâm on 07/10/2023.
//

import UIKit

class HomePageViewController: UIViewController {

    @IBOutlet weak var viewAvatar: UIView!
    @IBOutlet weak var imgAvatar: UIImageView!
    @IBOutlet weak var collectionHome: UICollectionView!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblNote: UILabel!
    
    var viewModel: HomeViewModel = HomeViewModel()
    //var cellDataSource: [Notes] = []
    var cellDataSource: [NoteCollectionCellViewModel] = []
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        viewModel.showAvatar { data in
            if let data = data {
                DispatchQueue.main.async {
                    self.imgAvatar.image = UIImage(data: data)
                }
            } else {
            }
        }
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        viewModel.getData()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configView()
        bindViewModel()
    }
    func configView() {
        viewAvatar.layer.cornerRadius = UIScreen.main.bounds.height * 25 / 932
        viewAvatar.layer.shadowColor = UIColor(red: 0.012, green: 0.016, blue: 0.016, alpha: 0.5).cgColor
        viewAvatar.layer.shadowOffset = CGSize(width: 0, height: 3)
        viewAvatar.layer.shadowRadius = 2
        viewAvatar.layer.shadowOpacity = 0.5
        viewAvatar.layer.masksToBounds = false
        imgAvatar.layer.cornerRadius = UIScreen.main.bounds.height * 20 / 932
        setupCollectionView()
    }
    
    func bindViewModel() {
        viewModel.isLoading.bind { [weak self] isLoading in
            guard let self = self, let isLoading = isLoading else {
                return
            }
            DispatchQueue.main.async {
                if isLoading {
                    self.activityIndicator.startAnimating()
                } else {
                    self.activityIndicator.stopAnimating()
                }
            }
        }
        viewModel.cellDataSource.bind { [weak self] notes in
            guard let self = self, let notes = notes else {
                return
            }
            self.cellDataSource = notes
            lblNote.text = String(viewModel.getTotalNote()) + " Notes"
            self.reloadCollectionView()
        }
    }
}
