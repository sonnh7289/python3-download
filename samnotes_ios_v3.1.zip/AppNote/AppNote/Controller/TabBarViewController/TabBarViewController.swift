//
//  TabBarViewController.swift
//  Note_IOS_V2.0
//
//  Created by Vũ Ngọc Lâm on 05/10/2023.
//

import UIKit

class TabBarViewController: UIViewController {
    @IBOutlet weak var contenView: UIView!
    @IBOutlet weak var homeStackView: UIStackView!
    @IBOutlet weak var chatStackView: UIStackView!
    @IBOutlet weak var imgHome: UIImageView!
    @IBOutlet weak var imgCalender: UIImageView!
    @IBOutlet weak var imgChat: UIImageView!
    @IBOutlet weak var imgProfile: UIImageView!
    
    func ViewConfig() {
        homeStackView.spacing = UIScreen.main.bounds.size.height * 44 / 932
        chatStackView.spacing = UIScreen.main.bounds.size.height * 44 / 932
        imgHome.image = UIImage(named: "iconHomeXanh")
        imgCalender.image = UIImage(named: "iconLichDen")
        imgChat.image = UIImage(named: "iconTNDen")
        imgProfile.image = UIImage(named: "iconPrrofileDen")
        let home = HomePageViewController(nibName: "HomePageViewController", bundle: nil)
        self.addChild(home)
        self.contenView.addSubview(home.view)
        home.didMove(toParent: self)
    }
    @IBAction func clickTabBar(_ sender: UIButton) {
        let tag = sender.tag
        if tag == 1 {
            let home = HomePageViewController(nibName: "HomePageViewController", bundle: nil)
            self.addChild(home)
            self.contenView.addSubview(home.view)
            imgHome.image = UIImage(named: "iconHomeXanh")
            imgCalender.image = UIImage(named: "iconLichDen")
            imgChat.image = UIImage(named: "iconTNDen")
            imgProfile.image = UIImage(named: "iconPrrofileDen")
            home.view.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                home.view.topAnchor.constraint(equalTo: self.contenView.topAnchor),
                home.view.leadingAnchor.constraint(equalTo: self.contenView.leadingAnchor),
                home.view.trailingAnchor.constraint(equalTo: self.contenView.trailingAnchor),
                home.view.bottomAnchor.constraint(equalTo: self.contenView.bottomAnchor)
            ])
            home.didMove(toParent: self)
        } else if tag == 2 {
            let schedule = ScheduleViewController(nibName: "ScheduleViewController", bundle: nil)
            self.addChild(schedule)
            self.contenView.addSubview(schedule.view)
            imgHome.image = UIImage(named: "iconHomeDen")
            imgCalender.image = UIImage(named: "iconLichXanh")
            imgChat.image = UIImage(named: "iconTNDen")
            imgProfile.image = UIImage(named: "iconPrrofileDen")
            schedule.didMove(toParent: self)
        } else if tag == 3 {
            let chat = ChatViewController(nibName: "ChatViewController", bundle: nil)
            self.addChild(chat)
            self.contenView.addSubview(chat.view)
            imgHome.image = UIImage(named: "iconHomeDen")
            imgCalender.image = UIImage(named: "iconLichDen")
            imgChat.image = UIImage(named: "iconTNXanh")
            imgProfile.image = UIImage(named: "iconPrrofileDen")
            chat.didMove(toParent: self)
        } else {
            let profile = ProfileViewController(nibName: "ProfileViewController", bundle: nil)
            self.addChild(profile)
            self.contenView.addSubview(profile.view)
            imgHome.image = UIImage(named: "iconHomeDen")
            imgCalender.image = UIImage(named: "iconLichDen")
            imgChat.image = UIImage(named: "iconTNDen")
            imgProfile.image = UIImage(named: "iconFrofilexanh")
            profile.didMove(toParent: self)
        }
    }
}
