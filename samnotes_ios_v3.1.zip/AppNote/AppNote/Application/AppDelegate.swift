//
//  AppDelegate.swift
//  AppNote
//
//  Created by Vũ Ngọc Lâm on 06/10/2023.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        let window = UIWindow(frame: UIScreen.main.bounds)
        if AppConstant.userId == nil {
            let navigationController = UINavigationController(rootViewController: OnboardingViewController())
            window.rootViewController = navigationController
        } else {
            let navigationController = UINavigationController(rootViewController: TabBarViewController())
            window.rootViewController = navigationController
        }
        
        window.makeKeyAndVisible()
        
        self.window = window
        return true
    }
}

