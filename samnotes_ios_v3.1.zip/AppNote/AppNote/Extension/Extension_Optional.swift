//
//  Extension_Optional.swift
//  Note_IOS_V2.0
//
//  Created by Vũ Ngọc Lâm on 30/09/2023.
//

import Foundation

extension Optional {
    func asStringOrEmpty() -> String {
        switch self {
        case .some(let value):
            return String(describing: value)
        case _:
            return ""
        }
    }
}
