//
//  Extension_UIVIew.swift
//  AppNote
//
//  Created by Vũ Ngọc Lâm on 10/10/2023.
//

import Foundation
import UIKit

extension UIView {
    func round( _ radiuis: CGFloat) {
        self.layer.cornerRadius = radiuis
        self.clipsToBounds = true
    }
}
