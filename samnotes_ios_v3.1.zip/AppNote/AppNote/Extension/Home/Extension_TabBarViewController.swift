//
//  Extension_TabBarViewController.swift
//  Note_IOS_V2.0
//
//  Created by Vũ Ngọc Lâm on 05/10/2023.
//

import Foundation
import UIKit

extension TabBarViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        ViewConfig()
    }
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
}
