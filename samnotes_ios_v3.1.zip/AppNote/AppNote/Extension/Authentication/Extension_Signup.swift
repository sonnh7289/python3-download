//
//  Extension_Signup.swift
//  Note_IOS_V2.0
//
//  Created by Vũ Ngọc Lâm on 28/09/2023.
//

import Foundation
import UIKit

extension SignupViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        viewConfig()
    }
}
extension SignupViewController {
    @IBAction func btnback(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: false)
    }
    @IBAction func btnSignUp(_ sender: UIButton) {
        print("Sign Up!")
    }
    @IBAction func showPass(_ sender: UIButton) {
        passTextField.isSecureTextEntry = !passTextField.isSecureTextEntry
        retypeTextField.isSecureTextEntry = !retypeTextField.isSecureTextEntry
        if passTextField.isSecureTextEntry == true
        {
            showpassButton.setBackgroundImage(UIImage(named: "eye"), for: UIControl.State.normal)
            showretypeButton.setBackgroundImage(UIImage(named: "eye"), for: UIControl.State.normal)
        }
        else
        {
            showpassButton.setBackgroundImage(UIImage(named: "showEye"), for: UIControl.State.normal)
            showretypeButton.setBackgroundImage(UIImage(named: "showEye"), for: UIControl.State.normal)
        }
    }
    @IBAction func rememberPass(_ sender: UIButton) {
        isCheck.toggle()
        if(isCheck == true)
        {
            rememberButton.setBackgroundImage(UIImage(named: "tickBox"), for: UIControl.State.normal)
        }
        else
        {
            rememberButton.setBackgroundImage(UIImage(named: "box"), for: UIControl.State.normal)
        }
    }
    @IBAction func btnFacebook(_ sender: UIButton) {
        print("facebook!")
    }
    @IBAction func btnGoogle(_ sender: UIButton) {
        print("google!")
    }
    @IBAction func btnApple(_ sender: UIButton) {
        print("Apple!")
    }
    @objc func tapSignIn() {
        self.navigationController?.pushViewController(LoginViewController(nibName: LoginViewController.className, bundle: nil), animated: true)
    }
}
