//
//  Extension_LoginWith.swift
//  Note_IOS_V2.0
//
//  Created by Vũ Ngọc Lâm on 28/09/2023.
//

import Foundation
import UIKit

extension LoginWithViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        viewConfig()
    }
}
extension LoginWithViewController {
    @IBAction func btnFacebook(_ sender: UIButton) {
        print("Facebook!")
    }
    @IBAction func btnGoogle(_ sender: UIButton) {
        print("Google!")
    }
    @IBAction func btnApple(_ sender: UIButton) {
        print("Apple!")
    }
    @IBAction func btnSignin(_ sender: UIButton) {
        self.navigationController?.pushViewController(LoginViewController(nibName: LoginViewController.className, bundle: nil), animated: true)
    }
    @objc func tapSignUp() {
        self.navigationController?.pushViewController(SignupViewController(nibName: SignupViewController.className, bundle: nil), animated: true)
    }
}
