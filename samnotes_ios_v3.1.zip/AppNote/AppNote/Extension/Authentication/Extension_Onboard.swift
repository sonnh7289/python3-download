//
//  Extension_Onboard.swift
//  Note_IOS_V2.0
//
//  Created by Vũ Ngọc Lâm on 27/09/2023.
//

import UIKit

extension OnboardingViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        onBoardCollectionView.dataSource = self
        onBoardCollectionView.delegate = self
        onBoardCollectionView.isUserInteractionEnabled = false
        onBoardCollectionView.register(UINib(nibName: OnboardingCell.className, bundle: nil), forCellWithReuseIdentifier: OnboardingCell.className)
        pageControl.page = 0
    }
}
extension OnboardingViewController {
    
    @IBAction func skipButtonAction(_ sender: UIButton) {
        self.navigationController?.pushViewController(LoginWithViewController(nibName: LoginWithViewController.className, bundle: nil), animated: true)
    }
    @IBAction func nextButtonAction(_ sender: UIButton) {
        let visibleItems: NSArray = self.onBoardCollectionView.indexPathsForVisibleItems as NSArray
        let currentItem: IndexPath = visibleItems.object(at: 0) as! IndexPath
        let nextItem: IndexPath = IndexPath(item: currentItem.item + 1,
                                            section: 0)
        if nextItem.row < AppContain.titleArray.count {
            self.onBoardCollectionView.scrollToItem(at: nextItem,
                                         at: .centeredHorizontally,
                                         animated: true)
        }
        let currentPage = pageControl.currentPage
            if currentPage < pageControl.numberOfPages - 1 {
                pageControl.currentPage = currentPage + 1
            }
            else {
                self.navigationController?.pushViewController(LoginWithViewController(nibName: LoginWithViewController.className, bundle: nil), animated: true)
            }
    }
    @IBAction func pageValueChange(_ sender: Any) {
        showItem(at: pageControl.currentPage)
    }
}
extension OnboardingViewController {
    private func showItem(at index: Int) {
        pageControl.page = index
        let indexPath = IndexPath(item: index, section: 0)
        onBoardCollectionView.scrollToItem(at: indexPath, at: [.centeredHorizontally, .centeredVertically], animated: true)
    }
}
extension OnboardingViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return AppContain.titleArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = onBoardCollectionView.dequeueReusableCell(withReuseIdentifier: OnboardingCell.className, for: indexPath) as! OnboardingCell
        
        cell.artImageView.image = AppContain.imageArray[indexPath.row]
        cell.headingLable.text = AppContain.titleArray[indexPath.row]
        cell.subHeadingLabel.text = AppContain.subTitleArray[indexPath.row]
        
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: onBoardCollectionView.frame.width,
                      height: onBoardCollectionView.frame.height)
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let pageWith = scrollView.frame.size.width
        let page = Int(floor((scrollView.contentOffset.x - pageWith / 2) / pageWith) + 1 )
        pageControl.page = page
    }
}
extension UIPageControl {
    var page: Int {
        get {
            return currentPage
        }
        set {
            currentPage = newValue
            
            for index in 0..<numberOfPages where index != newValue {
                setIndicatorImage(AppConstant.page, forPage: index)
            }
            setIndicatorImage(AppConstant.pageSelected, forPage: newValue)
        }
    }
}
