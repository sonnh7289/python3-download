//
//  Extension_Login.swift
//  Note_IOS_V2.0
//
//  Created by Vũ Ngọc Lâm on 28/09/2023.
//

import UIKit
import Toast_Swift

extension LoginViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        viewConfig()
        callApiIP()
    }
}
extension LoginViewController {
    func callApiIP() {
        
    }
    @IBAction func btnBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: false)
    }
    @IBAction func btnSignIn(_ sender: UIButton) {
        guard emailTextField.text != "" && passTextField.text != "" else {
            if emailTextField.text == "" {
                self.view.makeToast("Email không được để trống!", position: .top)
            } else {
                self.view.makeToast("Password không được để trống!", position: .top)
            }
            return
        }
        LoginAPI.shared.Login(user_name: emailTextField.text.asStringOrEmpty(),
                              password: passTextField.text.asStringOrEmpty()) { result in
            switch result {
            case .success(let success):
                //print("kết quả: \(success)")
                guard success.user?.id != nil else {
                    self.view.makeToast(success.message, position: .top)
                    return
                }
                AppConstant.saveUser(model: success)
                self.view.makeToast(success.message, position: .top)
                self.navigationController?.setRootViewController(viewController: TabBarViewController(),
                                                                 controllerType: TabBarViewController.self)
//                self.navigationController?.setRootViewController(viewController: TabBarViewController(), controllerType: TabBarViewController.self)
            case .failure(let failure):
                print(failure)
            }
        }
    }
    @IBAction func showPass(_ sender: UIButton) {
        passTextField.isSecureTextEntry = !passTextField.isSecureTextEntry
        if passTextField.isSecureTextEntry == true
        {
            showPass.setBackgroundImage(UIImage(named: "eye"), for: UIControl.State.normal)
        }
        else
        {
            showPass.setBackgroundImage(UIImage(named: "showEye"), for: UIControl.State.normal)
        }
    }
    @IBAction func rememberPass(_ sender: UIButton) {
        isCheck.toggle()
        if(isCheck == true)
        {
            rememberPass.setBackgroundImage(UIImage(named: "tickBox"), for: UIControl.State.normal)
        }
        else
        {
            rememberPass.setBackgroundImage(UIImage(named: "box"), for: UIControl.State.normal)
        }
    }
    @IBAction func btnFacebook(_ sender: UIButton) {
        print("facebook!")
    }
    @IBAction func btnGoogle(_ sender: UIButton) {
        print("google!")
    }
    @IBAction func btnApple(_ sender: UIButton) {
        print("Apple!")
    }
    @objc func tapForgot() {
        print("Forgot password!")
    }
    @objc func tapSignUp() {
        self.navigationController?.pushViewController(SignupViewController(nibName: SignupViewController.className, bundle: nil), animated: true)
    }
}
