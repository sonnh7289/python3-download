//
//  Extension_NSobject.swift
//  Note_IOS_V2.0
//
//  Created by Vũ Ngọc Lâm on 28/09/2023.
//

import Foundation

extension NSObject {
    var className: String {
        return String(describing: type(of: self))
    }
    
    class var className: String {
        return String(describing: self)
    }
}
