import './Happy.scss';

function Happy() {
    return <div>hello form happy</div>;
}

export default Happy;
