function Shopping() {
    return <div>Hello from shopping</div>;
}

export default Shopping;
