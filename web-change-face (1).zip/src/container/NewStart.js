function NewStart() {
    return <div>hello newstart</div>;
}

export default NewStart;
