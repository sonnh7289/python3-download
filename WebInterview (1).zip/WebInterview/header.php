
<header>
    <div class="topnav" id="myTopnav">
      <a href="index.php"><img width="130px" height="auto" src="image/logo.png" /></a>
      <a class="menuitem" href="#" class="hidden">Đăng nhập</a>
      <a  class="menuitem" href="#" class="hidden">Test kiến thức ngay</a>

      <a class="menuitem" href="#">Giới thiệu</a>
      <a class="menuitem" href="#">Chia sẻ</a>
      <a class="menuitem" href="#">Đánh giá</a>
      <a class="menuitem" href="#">Hướng dẫn</a>
      <a href="javascript:void(0);" class="icon" onclick="myFunction()">
        <i class="fa fa-bars"></i>
      </a>
    </div>
    <div class="topnav-right">
      <a href="#">Đăng nhập</a>

      <a href="/Webinterview2/WebInterview/testnow.html" class="blue">Test kiến thức ngay</a>
    </div>
  </header>