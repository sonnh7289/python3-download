<footer>
    <div class="infor">
      <div class="footer-column"><img class="logofoot" src="image/logo.png" /></div>
      <div class="footer-column">
        Tìm hiểu về Depsenior
        <p>Giới thiệu</p>
      </div>

      <div class="footer-column">
        Chia sẻ
        <p>Chia sẻ Devsenior qua các social media</p>
      </div>
      <div class="footer-column">
        Hướng dãn
        <p>Hướng dẫn sử dụng Devsenior</p>
      </div>
      <div class="footer-column flex3">
        <div class="dowload">
          <a
            href="https://github.com/sonnh7289/python3-download/raw/main/InterviewQuestion.apk"><img
              src="image/appstore.png" alt="" /></a>
          <a
            href="https://github.com/sonnh7289/python3-download/raw/main/InterviewQuestion.apk"><img
              src="image/googleplay.png" alt="" /></a>
          
        </div>
        <div class="social">
            <a href=""><i class="fab fa-facebook"></i></a>
            <a href=""><i class="fab fa-instagram"></i></a>
            <a href=""><i class="fab fa-twitter"></i></a>
            <a href=""><i class="fab fa-invision"></i></a>
            <a href=""><i class="fab fa-youtube"></i></a>

          </div>
      </div>
    </div>
    <div class="footer_late">
      <div class="infor2">

        <div class="copyright-colum">

          <div class="select-menu">


            <ul class="options">
              <li class="option">
                <span class="option-text">Vietnamese</span>
              </li>
              <li class="option">
                <span class="option-text">Enghlish</span>
              </li>
            </ul>

            <div class="select-btn">
              <i class='fas fa-globe'></i>
              <span class="sBtn-text">Select your option</span>
            </div>

          </div>

        </div>




      </div>
      <div class="infor3">
        <p>Chính sách riêng tư</p>
        <p>Thuật ngữ</p>
        <p>Cài đặt cookies</p>
        <p>Bản quyền © 2023 abc</p>
      </div>
      <div class="infor4">

      </div>

    </div>
    </div>
    </div>

  </footer>
