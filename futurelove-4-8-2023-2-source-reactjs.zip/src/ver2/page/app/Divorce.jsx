import React, { useState, useEffect } from "react";
import axios from "axios";
import Empty from "./template/EmptyTemplate";
import Template0 from "./template/Template1"
import Template1 from "./template/Template2"
import Template2 from "./template/Template3"
import Template3 from "./template/Template4"
import { useParams } from 'react-router-dom';

const templateComponents = {
    Template0: Template0, 
    Template1: Template1,
    Template2: Template2,
    Template3: Template3,
  };

function Divorce() {

    const [data, setData] = useState([])
    const { id } = useParams();
    const [template, setTemplate] = useState("Template0")

    const fetchData = async () => {
        try {
            const response = await axios.get(
                `http://14.225.7.221:8989/lovehistory/272`
            )
            setData(response.data.sukien[4])
            console.log(response.data.sukien[4])
            setTemplate("Template"+response.data.sukien[5].id_template)
            console.log("Template"+response.data.sukien[5].id_template)
        } catch (err) {
            console.log(err)
        }
    }
    useEffect(() => {
        fetchData();
    }, []);

    const TemplateComponent = templateComponents[template];

    return (
        <div className="flex items-center justify-center h-full">
            { data ?  < TemplateComponent data={data}/> :  <Empty/> }
        </div>
    );
}

export default Divorce;