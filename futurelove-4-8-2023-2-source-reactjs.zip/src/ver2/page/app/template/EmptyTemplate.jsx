function EmptyTemplate () {
    return (
        <div
            className={` lg:w-[1019px] w-[380px] mb-12 border-8 border-pink-300  h-[573px] bg-white rounded-[36px] flex flex-row items-center justify-center`}
        >
            <h1 className="text-5xl">Bạn chưa có sự kiện nào. Hãy thêm một sự kiện đáng chú ý!</h1>

        </div>
    )
}
export default EmptyTemplate;