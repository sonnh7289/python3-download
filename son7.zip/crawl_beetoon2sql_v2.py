from bs4 import BeautifulSoup
from urllib.parse import urlparse
import requests
import json
import mysql.connector
from datetime import datetime
from beetoon.beetoon2sql import beetoon_insert
import re

mydb = beetoon_insert(password="mira@123",db='hub_manga')
beetoon_crawl = list()

def remove_non_letters(input_string):
    return re.sub(r'[^a-zA-Z\s]+', '', input_string)

'''
genre : Chủ đề
start : Trang bắt đầu crawl
end   : Trang kết thúc crawl
'''
def crawl_beetoon_data(genre, start, end):
    cnt = start
    base = 'https://ww5.beetoon.net/'
    display_url = 'ww6.beetoon.net'
    base_url = 'https://ww6.beetoon.net/'
    url = base + genre
    manga_id = 0
    author_id = []
    cate_list = []
    author_list = []
    cnt_author_id = 1
    now = datetime.now()
    current_time = 1
    # MySQL : INSERT TABLE 'domain_crawlers'
    mydb.insert_2_domain_crawlers(domain_name=base,
    display_name=display_url, description=base_url, 
    created_at=current_time, updated_at=current_time)

    # XỬ LÝ TỪNG TRANG TRONG MỤC ĐÃ CHỌN (LASTEST-UPDATE)
    while (cnt <= end):
        # LẤY SOURCE CODE CỦA TRANG
        pageUrl = url + '/page-' + str(cnt)
        r = requests.get(pageUrl)
        soup = BeautifulSoup(r.content, 'html.parser')

        # TẤT CẢ CÁC BỘ MANGA TRONG PAGE
        comics = soup.find('div', class_="comics-grid")
        
        # CRAWL DATA TỪNG Chapter TRUYỆN --> 
        # manga_id = int, manga_name = str , thumbnail = jpg, author = str,
        # categories = list, last-update = str, chapters = dict
        for link in comics.findAll('div', class_="entry"):

            linkManga_base = link.a['href']
            rManga_base = requests.get(linkManga_base)
            soupManga_base = BeautifulSoup(rManga_base.content, 'html.parser')
            table_name = 'data_crawl'
            manga_id = manga_id + 1
            manga_name = None
            author = None
            categories = None
            date_time = "Ongoing"
            chapter_list = []
            chapterid = 1
            chapters = list()
            data_crawl = dict()

            # MANGA NAME
            manga_name = soupManga_base.find('h1', class_='name bigger').text

            # THUMBNAIL MANGA
            thumbnail = soupManga_base.find('div', 'thumb text-center').img['src']
            
            # AUTHORS MANGA
            author = ""
            authors = soupManga_base.find('div', 'author')
            for a in authors.find_all('a', title=True):
                name_author = a['title'] + ", "
                author += name_author
            author = author[:-2]
            
            # MySQL : INSERT TABLE 'authors'
            for author_name in author.replace(" ","").split(","):
                if author_name not in authors:
                    author_list.append(author_name)
                    author_id.append(cnt_author_id)
                    cnt_author_id += 1
                    mydb.insert_2_authors(name=author_name, created_at=current_time, updated_at=current_time)

            # MANGA DESCRIPTION
            desc = soupManga_base.find('div', {"id": "desc"}).text

            # CATEGORIES
            categories = []
            cats = soupManga_base.find('div', class_="genre")
            manga_released_date="updating"
            for category in cats.find_all('a', href=True):
                categories.append(category.text)
            try:
                # LAST UPDATE
                date_time = soupManga_base.find('div', class_='chapter-date')['title']
                
                # MANGA ID
                yyyy = date_time[6:10]
                mm = date_time[:2]
                dd = date_time[3:5]
                time = "".join(date_time[11:].split(':'))
                # manga_released_date = yyyy + mm + dd

                date_time = date_time.split(" ")[0]
            except Exception as e:
                print(e)

            

            # MySQL : INSERT TABLE : 'categories'
            slug=""
            title=""
            for i in categories:
                title = title + "\n" + i
                i = i.lower().replace(" ","-")
                slug = slug + "-" + i
            title = "Genre(s):" + title
            slug = "genres"+ slug
            mydb.insert_2_categories(domain_id=1, title=title, slug=slug, image=None,
             description=None, created_at=current_time, updated_at=current_time)

            print("Manga_ID:", manga_id)
            print("\nManga_NAME:", manga_name)
            print("\nThumbail URL:", thumbnail)
            print("\nAuthor:", author)
            print("\nCategory:",categories)
            print("\nTime:", date_time)
            print("\nManga URL:", linkManga_base)

            # DUYỆT TỪNG PAGE TRUYỆN TRONG 1 MANGA
            last_page = 1
            last_page_tmp = 0
            cnt_page = 1
            for pageManga in soupManga_base.findAll('a', class_ = 'next page-numbers')[1:2]:
                last_page = int(pageManga.get('href').split("/")[4].split("-")[1])
                # print("\npageManga:",pageManga.get('href').split("/"))
            print("\nLast_page:", last_page)

            # LẤY URL TỪNG CHAPTER
            while last_page>=cnt:
                # LẤY LINK MANGA
                linkManga = linkManga_base + '/page-' + str(last_page)
                print("Page{}".format(last_page), linkManga)

                # LẤY DATA TỪ MANGA
                rManga = requests.get(linkManga)
                soupManga = BeautifulSoup(rManga.content, 'html.parser')

                # Release date
                if last_page_tmp == last_page:
                    for i in soupManga.findAll('div', class_ = 'items-chapters'):
                        for x in i.findAll('a')[-1:]:
                            manga_released_date = x.div.div.div['title']
                            print(x['href'], manga_released_date)
                # LẤY TÊN CÁC CHAPTER TRONG PAGE
                for chaptername in soupManga.findAll('h2', class_="chap")[::-1]:
                    chaptername = chaptername.text.replace("  ", "-").lower()
                    chapter_list.append((chaptername[:-1].replace(".","-"), chapterid))
                    
                    chapterid += 1
                last_page -= 1
            
            # print("\nChapter list:", chapter_list)
            if len(chapter_list) > 0:
                for i in range(len(chapter_list)):
                    # chapter_id, chapter_name, page_list
                    chapter_id = chapter_list[i][1]
                    chaptername = None
                    chapter_name = None
                    chapter = dict()
                    page_list = []

                    # LẤY DATA TỪNG CHAPTER
                    linkChapter = linkManga_base + '-' + chapter_list[i][0] + '/'
                    # print("Link chapter : \n\n", linkChapter)
                    rChapter = requests.get(linkChapter)
                    soupChapter = BeautifulSoup(rChapter.content, 'html.parser')

                    # TÊN CHAPTER + KIỂM TRA ĐÃ CRAWL CHƯA
                    try:
                        soup_content = soupChapter.find('div', class_='chapter-content-inner text-center')
                        chaptername = soup_content.img['alt']
                        chapter_name = chaptername[:-14]
                        print("\nChapter Name: ", chaptername)
                    except Exception as e:
                        print(e)
                    
                    # CRAWL ẢNH TỪNG CHAPTER
                    for img in soupChapter.findAll('img', attrs={'alt': chaptername}):
                        src = img['src'].replace('\n', '')
                        page_list.append(src)
                    # THÊM KEY Chapters vào DATA CHÍNH
                    chapter['chapter_id'] = chapter_id
                    chapter['chapter_name'] = chapter_name
                    chapter['page_list'] = page_list
                    chapters.append(chapter)

                    # MySQL : INSERT TABLE 'chapters'
                    mydb.insert_2_chapters(manga_id=manga_id, name=chapter['chapter_name'],
                     created_at=current_time, updated_at=current_time)
                    
                    # MySQL : INSERT TABLE 'chapter_thumbnails'
                    for chapter_thumbnail_url in chapter['page_list']:
                        mydb.insert_2_chapter_thumbnails(chapter_id=chapter['chapter_id'], 
                        thumbnail_url=chapter_thumbnail_url,
                        created_at= current_time, updated_at=current_time)

                    
            # print("\nchapters:", chapters)
            data_crawl['manga_id'] = manga_id
            data_crawl['manga_name'] = manga_name
            data_crawl['thumbnail'] = thumbnail
            data_crawl['author'] = author
            data_crawl['last-update'] = date_time
            data_crawl['categories'] = categories
            data_crawl['chapters'] = chapters

            manga_title = data_crawl['manga_name']
            manga_slug = remove_non_letters(manga_title).lower().replace(" ","-")
            manga_image = data_crawl['thumbnail']
            manga_chapter_count = len(data_crawl['chapters'])
            # MySQL : INSERT TABLE 'manga'
            mydb.insert_2_manga(domain_id=1, title=manga_title, slug=manga_slug, 
            image=manga_image, description=desc, release_at=manga_released_date,
            created_at=current_time, updated_at=current_time)

            # MySQL : INSERT TABLE 'manga_authors'
            manga_authors_author_id = []
            for author_name in author.replace(" ","").split(","):
                manga_authors_author_id.append(author_list.index(author_name))
            mydb.insert_2_manga_authors(manga_id=manga_id, author_id=manga_authors_author_id)

            # MySQL : INSERT TABLE 'manga_categories'
            for category in categories:
                if category not in cate_list:
                    cate_list.append(category)

            beetoon_crawl.append(data_crawl)
            # print("\ndata beetoon crawl:", beetoon_crawl)
            print("---"*20)
        cnt+=1

    # MySQL : INSERT TABLE 'manga_categories'
    for category in cate_list:
        manga_id_list=[]
        for beetoon_crawl_data in beetoon_crawl:
            if category in beetoon_crawl_data['categories']:
                manga_id_list.append(beetoon_crawl_data['manga_id'])
        mydb.insert_2_manga_categories(category_id=cate_list.index(category) + 1,
                    manga_id=manga_id_list)

    # MySQL : INSERT TABLE 'categories_name'
    for category in cate_list:
        mydb.insert_2_categories_name(category_id=cate_list.index(category), 
        category_name=category)

crawl_beetoon_data('latest-update', 1, 1)

with open('data1.json', 'w', encoding="utf-8") as f:
    json.dump(beetoon_crawl, f, indent=4)