//
//  cameraVC.swift
//  FakeLocationV3
//
//  Created by Đỗ Việt on 08/04/2023.
//

import UIKit
import AVFoundation

class cameraVC: UIViewController, UIImagePickerControllerDelegate & UINavigationControllerDelegate {
    
    var session: AVCaptureSession?
    let output = AVCapturePhotoOutput()
    let previewLayer = AVCaptureVideoPreviewLayer()
    
    let minimumZoom: CGFloat = 1.0
    let maximumZoom: CGFloat = 8.0
    var lastZoomFactor: CGFloat = 1.0
    var newCamera: AVCaptureDevice?
    
    var currentOrientation: UIDeviceOrientation = .portrait
    
    var linkImage = ""
    var image1 = UIImage()
    
    var mode = ""
    
    private let shutterButton: UIButton = {
        let button = UIButton(frame: CGRect(x: 0, y: 0, width: 69, height: 69))
        button.setBackgroundImage(UIImage(named: "Ellipse 8"), for: .normal)
        button.setImage(UIImage(named: "Ellipse 7"), for: .normal)
        return button
    }()
    
    private let imageButton: UIButton = {
        let button = UIButton(frame: CGRect(x: 0, y: 0, width: 40, height: 40))
        button.setImage(UIImage(named: "Ellipse 10"), for: .normal)
        return button
    }()
    
    private let backButton: UIButton = {
        let button = UIButton(frame: CGRect(x: 0, y: 0, width: 40, height: 40))
        button.setImage(UIImage(named: "Ellipse 9"), for: .normal)
        return button
    }()
    
    private let changeCamButton: UIButton = {
        let button = UIButton(frame: CGRect(x: 0, y: 0, width: 40, height: 40))
        button.setImage(UIImage(named: "rotate"), for: .normal)
        return button
    }()
    
    var imagePicker = UIImagePickerController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        view.layer.addSublayer(previewLayer)
        view.addSubview(shutterButton)
        view.addSubview(imageButton)
        view.addSubview(backButton)
        view.addSubview(changeCamButton)
        checkCameraPermissions()
        shutterButton.addTarget(self, action: #selector(didTapTakePhoto), for: .touchUpInside)
        imageButton.addTarget(self, action: #selector(didTapImage), for: .touchUpInside)
        backButton.addTarget(self, action: #selector(didTapBack), for: .touchUpInside)
        changeCamButton.addTarget(self, action: #selector(didTapChangeCam), for: .touchUpInside)
    }
    
    @objc func pinch(_ pinch: UIPinchGestureRecognizer) {
        guard let device = newCamera else { return }
        
        // Return zoom value between the minimum and maximum zoom values
        func minMaxZoom(_ factor: CGFloat) -> CGFloat {
            return min(min(max(factor, minimumZoom), maximumZoom), device.activeFormat.videoMaxZoomFactor)
        }
        
        func update(scale factor: CGFloat) {
            do {
                try device.lockForConfiguration()
                defer { device.unlockForConfiguration() }
                device.videoZoomFactor = factor
            } catch {
                print("\(error.localizedDescription)")
            }
        }
        
        let newScaleFactor = minMaxZoom(pinch.scale * lastZoomFactor)
        
        switch pinch.state {
        case .began: fallthrough
        case .changed: update(scale: newScaleFactor)
        case .ended:
            lastZoomFactor = minMaxZoom(newScaleFactor)
            update(scale: lastZoomFactor)
        default: break
        }
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        previewLayer.frame = view.bounds
        shutterButton.center = CGPoint(x: view.frame.size.width/2,
                                       y: view.frame.size.height - 55)
        imageButton.center = CGPoint(x: view.frame.size.width - 60,
                                     y: view.frame.size.height - 60)
        backButton.center = CGPoint(x: 60,
                                     y: view.frame.size.height - 60)
        changeCamButton.center = CGPoint(x: view.frame.size.width - 40,
                                     y: 60)
        
    }
    
    private func checkCameraPermissions(){
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video, completionHandler: {
                granted in
                guard granted else{
                    return
                }
                DispatchQueue.main.async {
                    self.setUpCamera()
                }
            })
        case .restricted:
            break
        case .authorized:
            setUpCamera()
        case .denied:
            break
        @unknown default:
            break
        }
    }
    
    private func setUpCamera() {
        let session = AVCaptureSession()
        do {
            newCamera = cameraWithPosition(.back)
            let input = try AVCaptureDeviceInput(device: newCamera!)
            if session.canAddInput(input){
                session.addInput(input)
            }
            if session.canAddOutput(output){
                session.addOutput(output)
            }
            
            previewLayer.videoGravity = .resizeAspectFill
            previewLayer.session = session
            
            session.startRunning()
            self.session = session
        }catch {
            print(error)
        }
        let pinchRecognizer = UIPinchGestureRecognizer(target: self, action:#selector(pinch(_:)))
        self.view.addGestureRecognizer(pinchRecognizer)
    }
    
    @objc private func didTapTakePhoto(){
        output.capturePhoto(with: AVCapturePhotoSettings(), delegate: self)
    }
    
    @objc private func didTapImage(){
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary){
            imagePicker.delegate = self
            imagePicker.sourceType = .photoLibrary
            imagePicker.allowsEditing = false
            
            present(imagePicker, animated: true, completion: nil)
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true, completion: nil)
        if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            if mode == "outBack" {
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let vc = storyboard.instantiateViewController(withIdentifier: "ViewController2") as! ViewController2
                vc.modalPresentationStyle = .fullScreen
                vc.image = image
                vc.mode = "outBack"
                self.present(vc, animated: true, completion: nil)
            }else{
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let vc = storyboard.instantiateViewController(withIdentifier: "EditVC") as! EditVC
                vc.modalPresentationStyle = .fullScreen
                vc.inputImage = image
                vc.linkImage = linkImage
                vc.bgImage = image1
                self.present(vc, animated: true, completion: nil)
            }
            //session?.stopRunning()
        }
        
    }
    
    @objc private func didTapBack(){
        self.dismiss(animated: true)
    }
    
    @objc private func didTapChangeCam(){
        if let session = self.session {
            let currentCameraInput: AVCaptureInput = session.inputs[0]
            session.removeInput(currentCameraInput)
            //newCamera = AVCaptureDevice.default(for: AVMediaType.video)!
            if (currentCameraInput as! AVCaptureDeviceInput).device.position == .back {
                UIView.transition(with: self.view, duration: 0.5, options: .transitionFlipFromLeft, animations: { [self] in
                    newCamera = self.cameraWithPosition(.front)!
                }, completion: nil)
            } else {
                UIView.transition(with: self.view, duration: 0.5, options: .transitionFlipFromRight, animations: { [self] in
                    newCamera = self.cameraWithPosition(.back)!
                }, completion: nil)
            }
            do {
                try self.session?.addInput(AVCaptureDeviceInput(device: newCamera!))
            }
            catch {
                print("error: \(error.localizedDescription)")
            }
            
        }
        
    }
    
    func cameraWithPosition(_ position: AVCaptureDevice.Position) -> AVCaptureDevice? {
        let deviceDescoverySession = AVCaptureDevice.DiscoverySession.init(deviceTypes: [AVCaptureDevice.DeviceType.builtInWideAngleCamera], mediaType: AVMediaType.video, position: AVCaptureDevice.Position.unspecified)

        for device in deviceDescoverySession.devices {
            if device.position == position {
                return device
            }
        }
        return nil
    }
}

extension cameraVC: AVCapturePhotoCaptureDelegate {
    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        
        guard let img = photo.cgImageRepresentation() else { return }
        let temp = CIImage(cgImage: img)
        var ciImage = temp;
        switch currentOrientation {
        case .portrait:
            ciImage = temp.oriented(forExifOrientation: 6)
        case .landscapeRight:
            ciImage = temp.oriented(forExifOrientation: 3)
        case .landscapeLeft:
            ciImage = temp.oriented(forExifOrientation: 1)
        default:
            break
        }
        
        guard let cgImage = CIContext(options: nil).createCGImage(ciImage, from: ciImage.extent) else { return }
        let fixedImage = UIImage(cgImage: cgImage)
        
        UIImageWriteToSavedPhotosAlbum(fixedImage, self, #selector(image(_:didFinishSavingWithError:contextInfo:)), nil)
        //session?.stopRunning()
    }
    
    @objc func image(_ image: UIImage, didFinishSavingWithError error: Error?, contextInfo: UnsafeRawPointer) {
        if let error = error {
            showAlertWith(title: "Save error", message: error.localizedDescription)
        } else {
            showAlertWith(title: "Saved!", message: "Your image has been saved to your photos.")
        }
    }
    
    func showAlertWith(title: String, message: String){
        let ac = UIAlertController(title: title, message: message, preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: "OK", style: .default))
        present(ac, animated: true)
    }
}
