package com.example.personalfinanceapp.data.model.onboarding

data class OnBoardingItem(
    val onBoardingImage: Int,
    val title: String,
    val description: String
)